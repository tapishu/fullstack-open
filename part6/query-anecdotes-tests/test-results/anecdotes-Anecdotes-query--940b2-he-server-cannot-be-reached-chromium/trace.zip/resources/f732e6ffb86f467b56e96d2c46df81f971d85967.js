import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import AnecdoteForm from "/src/components/AnecdoteForm.jsx?t=1791300349611";
import Notification from "/src/components/Notification.jsx";
import { useAnecdotes } from "/src/hooks/useAnecdotes.js?t=1791300349611";
var _jsxFileName = "/Users/takahashishuuta/Desktop/Script/FullStack/part6fprsubmission/query-anecdotes/src/App.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=977af748";
var _s = $RefreshSig$();
// Anecdotes
// anecdotes
const App = () => {
	_s();
	const { anecdotes, isPending, isError, voteAnecdote } = useAnecdotes();
	// const handleVote = (anecdote) => {
	//   console.log('vote')
	// }
	if (isPending) {
		return /* @__PURE__ */ _jsxDEV("div", { children: "loading data..." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 14,
			columnNumber: 12
		}, this);
	}
	if (isError) {
		return /* @__PURE__ */ _jsxDEV("div", { children: "anecdote service not available due to problems in server" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 17,
			columnNumber: 12
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", { children: [
		/* @__PURE__ */ _jsxDEV("h3", { children: "Anecdote app" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Notification, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(AnecdoteForm, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 24,
			columnNumber: 7
		}, this),
		anecdotes.map((anecdote) => /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", { children: anecdote.content }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 28,
			columnNumber: 11
		}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
			"has ",
			anecdote.votes,
			/* @__PURE__ */ _jsxDEV("button", {
				onClick: () => voteAnecdote(anecdote),
				children: "vote"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 13
			}, this)
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 29,
			columnNumber: 11
		}, this)] }, anecdote.id, true, {
			fileName: _jsxFileName,
			lineNumber: 27,
			columnNumber: 9
		}, this))
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 20,
		columnNumber: 5
	}, this);
};
_s(App, "5UHHezI/sU0avYEQnFFIa3whMAs=", false, function() {
	return [useAnecdotes];
});
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.jsx?t=1791300459590";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/takahashishuuta/Desktop/Script/FullStack/part6fprsubmission/query-anecdotes/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/takahashishuuta/Desktop/Script/FullStack/part6fprsubmission/query-anecdotes/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/takahashishuuta/Desktop/Script/FullStack/part6fprsubmission/query-anecdotes/src/App.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxrQkFBa0I7QUFDekIsT0FBTyxrQkFBa0I7QUFDekIsU0FBUyxvQkFBb0I7Ozs7OztBQUk3QixNQUFNLFlBQVk7O0NBRWhCLE1BQU0sRUFBQyxXQUFVLFdBQVUsU0FBUSxpQkFBZ0IsYUFBYTs7OztDQUk5RCxJQUFJLFdBQVc7RUFDZixPQUFPLHdCQUFDLE9BQUQsWUFBSyxrQkFBb0I7Ozs7O0NBQ2xDO0NBQ0YsSUFBSSxTQUFTO0VBQ1QsT0FBTyx3QkFBQyxPQUFELFlBQUssMkRBQTZEOzs7OztDQUMzRTtDQUNBLE9BQ0Usd0JBQUMsT0FBRDtFQUNFLHdCQUFDLE1BQUQsWUFBSSxlQUFnQjs7Ozs7RUFFcEIsd0JBQUMsY0FBRCxDQUFlOzs7OztFQUNmLHdCQUFDLGNBQUQsQ0FBZTs7Ozs7RUFFZCxVQUFVLEtBQUssYUFDZCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRCxZQUFNLFNBQVMsUUFBYTs7OztZQUM1Qix3QkFBQyxPQUFEO0dBQUs7R0FDRSxTQUFTO0dBQ2Qsd0JBQUMsVUFBRDtJQUFRLGVBQWUsYUFBYSxRQUFRO2NBQUc7R0FBWTs7Ozs7RUFDeEQ7Ozs7VUFDRixLQU5LLFNBQVM7Ozs7U0FNZCxDQUNOO0NBQ0U7Ozs7O0FBRVQ7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBcHAuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBBbmVjZG90ZUZvcm0gZnJvbSAnLi9jb21wb25lbnRzL0FuZWNkb3RlRm9ybSdcbmltcG9ydCBOb3RpZmljYXRpb24gZnJvbSAnLi9jb21wb25lbnRzL05vdGlmaWNhdGlvbidcbmltcG9ydCB7IHVzZUFuZWNkb3RlcyB9IGZyb20gJy4vaG9va3MvdXNlQW5lY2RvdGVzJ1xuXG4vLyBBbmVjZG90ZXNcbi8vIGFuZWNkb3Rlc1xuY29uc3QgQXBwID0gKCkgPT4ge1xuXG4gIGNvbnN0IHthbmVjZG90ZXMsaXNQZW5kaW5nLGlzRXJyb3Isdm90ZUFuZWNkb3RlfSA9IHVzZUFuZWNkb3RlcygpXG4gIC8vIGNvbnN0IGhhbmRsZVZvdGUgPSAoYW5lY2RvdGUpID0+IHtcbiAgLy8gICBjb25zb2xlLmxvZygndm90ZScpXG4gIC8vIH1cbiAgICBpZiAoaXNQZW5kaW5nKSB7XG4gICAgcmV0dXJuIDxkaXY+bG9hZGluZyBkYXRhLi4uPC9kaXY+XG4gIH1cbmlmIChpc0Vycm9yKSB7XG4gICAgcmV0dXJuIDxkaXY+YW5lY2RvdGUgc2VydmljZSBub3QgYXZhaWxhYmxlIGR1ZSB0byBwcm9ibGVtcyBpbiBzZXJ2ZXI8L2Rpdj5cbiAgfVxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8aDM+QW5lY2RvdGUgYXBwPC9oMz5cblxuICAgICAgPE5vdGlmaWNhdGlvbiAvPlxuICAgICAgPEFuZWNkb3RlRm9ybSAvPlxuXG4gICAgICB7YW5lY2RvdGVzLm1hcCgoYW5lY2RvdGUpID0+IChcbiAgICAgICAgPGRpdiBrZXk9e2FuZWNkb3RlLmlkfT5cbiAgICAgICAgICA8ZGl2PnthbmVjZG90ZS5jb250ZW50fTwvZGl2PlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICBoYXMge2FuZWNkb3RlLnZvdGVzfVxuICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiB2b3RlQW5lY2RvdGUoYW5lY2RvdGUpfT52b3RlPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKSl9XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwIl19