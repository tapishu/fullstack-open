import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Notification.jsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "/Users/takahashishuuta/Desktop/Script/FullStack/part6fprsubmission/query-anecdotes/src/components/Notification.jsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=977af748";
const Notification = () => {
	const style = {
		border: "solid",
		padding: 10,
		borderWidth: 1,
		marginBottom: 5
	};
	if (true) return null;
	return /* @__PURE__ */ _jsxDEV("div", {
		"data-testid": "notification",
		style
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 11,
		columnNumber: 10
	}, this);
};
_c = Notification;
export default Notification;
var _c;
$RefreshReg$(_c, "Notification");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Notification.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/takahashishuuta/Desktop/Script/FullStack/part6fprsubmission/query-anecdotes/src/components/Notification.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/takahashishuuta/Desktop/Script/FullStack/part6fprsubmission/query-anecdotes/src/components/Notification.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/takahashishuuta/Desktop/Script/FullStack/part6fprsubmission/query-anecdotes/src/components/Notification.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFBQSxNQUFNLHFCQUFxQjtDQUN6QixNQUFNLFFBQVE7RUFDWixRQUFRO0VBQ1IsU0FBUztFQUNULGFBQWE7RUFDYixjQUFjO0NBQ2hCO0NBRUEsSUFBSSxNQUFNLE9BQU87Q0FFakIsT0FBTyx3QkFBQyxPQUFEO0VBQUssZUFBWTtFQUFzQjtDQUFZOzs7OztBQUM1RDs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk5vdGlmaWNhdGlvbi5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiY29uc3QgTm90aWZpY2F0aW9uID0gKCkgPT4ge1xuICBjb25zdCBzdHlsZSA9IHtcbiAgICBib3JkZXI6IFwic29saWRcIixcbiAgICBwYWRkaW5nOiAxMCxcbiAgICBib3JkZXJXaWR0aDogMSxcbiAgICBtYXJnaW5Cb3R0b206IDUsXG4gIH1cblxuICBpZiAodHJ1ZSkgcmV0dXJuIG51bGxcblxuICByZXR1cm4gPGRpdiBkYXRhLXRlc3RpZD1cIm5vdGlmaWNhdGlvblwiIHN0eWxlPXtzdHlsZX0+PC9kaXY+XG59XG5cbmV4cG9ydCBkZWZhdWx0IE5vdGlmaWNhdGlvblxuIl19