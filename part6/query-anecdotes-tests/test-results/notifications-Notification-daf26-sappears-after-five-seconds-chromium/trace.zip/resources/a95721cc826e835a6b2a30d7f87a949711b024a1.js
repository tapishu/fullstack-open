import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AnecdoteForm.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { useAnecdotes } from "/src/hooks/useAnecdotes.js";
var _jsxFileName = "/Users/takahashishuuta/Desktop/Script/FullStack/part6fprsubmission/query-anecdotes/src/components/AnecdoteForm.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=977af748";
var _s = $RefreshSig$();
const AnecdoteForm = () => {
	_s();
	const { addAnecdote } = useAnecdotes();
	const onCreate = async (event) => {
		event.preventDefault();
		const content = event.target.anecdote.value;
		event.target.reset();
		addAnecdote(content);
	};
	return /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", { children: "create new" }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 14,
		columnNumber: 7
	}, this), /* @__PURE__ */ _jsxDEV("form", {
		onSubmit: onCreate,
		children: [/* @__PURE__ */ _jsxDEV("input", { name: "anecdote" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 16,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("button", {
			type: "submit",
			children: "create"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 17,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 5
	}, this);
};
_s(AnecdoteForm, "Sf3t0WNJ6/U9Xe7SDyHo3xJPc+8=", false, function() {
	return [useAnecdotes];
});
_c = AnecdoteForm;
export default AnecdoteForm;
var _c;
$RefreshReg$(_c, "AnecdoteForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/AnecdoteForm.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/takahashishuuta/Desktop/Script/FullStack/part6fprsubmission/query-anecdotes/src/components/AnecdoteForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/takahashishuuta/Desktop/Script/FullStack/part6fprsubmission/query-anecdotes/src/components/AnecdoteForm.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/takahashishuuta/Desktop/Script/FullStack/part6fprsubmission/query-anecdotes/src/components/AnecdoteForm.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxvQkFBb0I7Ozs7QUFDN0IsTUFBTSxxQkFBcUI7O0NBRXpCLE1BQU0sRUFBQyxnQkFBYyxhQUFhO0NBQ2xDLE1BQU0sV0FBVyxPQUFPLFVBQVU7RUFDaEMsTUFBTSxlQUFlO0VBQ3JCLE1BQU0sVUFBVSxNQUFNLE9BQU8sU0FBUztFQUN0QyxNQUFNLE9BQU8sTUFBTTtFQUV2QixZQUFZLE9BQU87Q0FBRztDQUVwQixPQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFELFlBQUksYUFBYzs7OztXQUNsQix3QkFBQyxRQUFEO0VBQU0sVUFBVTtZQUFoQixDQUNFLHdCQUFDLFNBQUQsRUFBTyxNQUFLLFdBQVk7Ozs7WUFDeEIsd0JBQUMsVUFBRDtHQUFRLE1BQUs7YUFBUztFQUFjOzs7O1VBQ2hDOzs7OztTQUNIOzs7OztBQUVUOzs7OztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQW5lY2RvdGVGb3JtLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VBbmVjZG90ZXMgfSBmcm9tICcuLi9ob29rcy91c2VBbmVjZG90ZXMnXG5jb25zdCBBbmVjZG90ZUZvcm0gPSAoKSA9PiB7XG5cbiAgY29uc3Qge2FkZEFuZWNkb3RlfT0gdXNlQW5lY2RvdGVzKClcbiAgY29uc3Qgb25DcmVhdGUgPSBhc3luYyAoZXZlbnQpID0+IHtcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXG4gICAgY29uc3QgY29udGVudCA9IGV2ZW50LnRhcmdldC5hbmVjZG90ZS52YWx1ZVxuICAgIGV2ZW50LnRhcmdldC5yZXNldCgpXG5cbmFkZEFuZWNkb3RlKGNvbnRlbnQpICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGgzPmNyZWF0ZSBuZXc8L2gzPlxuICAgICAgPGZvcm0gb25TdWJtaXQ9e29uQ3JlYXRlfT5cbiAgICAgICAgPGlucHV0IG5hbWU9XCJhbmVjZG90ZVwiIC8+XG4gICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiPmNyZWF0ZTwvYnV0dG9uPlxuICAgICAgPC9mb3JtPlxuICAgIDwvZGl2PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEFuZWNkb3RlRm9ybSJdfQ==