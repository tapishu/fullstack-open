import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import AnecdoteForm from "/src/components/AnecdoteForm.jsx";
import Notification from "/src/components/Notification.jsx";
import { useAnecdotes } from "/src/hooks/useAnecdotes.js";
var _jsxFileName = "/Users/takahashishuuta/Desktop/Script/FullStack/part6fprsubmission/query-anecdotes/src/App.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=977af748";
var _s = $RefreshSig$();
// Anecdotes
// anecdotes
const App = () => {
	_s();
	const { anecdotes, isPending, voteAnecdote } = useAnecdotes();
	// const handleVote = (anecdote) => {
	//   console.log('vote')
	// }
	if (isPending) {
		return /* @__PURE__ */ _jsxDEV("div", { children: "loading data..." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 14,
			columnNumber: 12
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", { children: [
		/* @__PURE__ */ _jsxDEV("h3", { children: "Anecdote app" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 19,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Notification, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(AnecdoteForm, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 22,
			columnNumber: 7
		}, this),
		anecdotes.map((anecdote) => /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", { children: anecdote.content }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 26,
			columnNumber: 11
		}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
			"has ",
			anecdote.votes,
			/* @__PURE__ */ _jsxDEV("button", {
				onClick: () => voteAnecdote(anecdote),
				children: "vote"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 13
			}, this)
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 27,
			columnNumber: 11
		}, this)] }, anecdote.id, true, {
			fileName: _jsxFileName,
			lineNumber: 25,
			columnNumber: 9
		}, this))
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 18,
		columnNumber: 5
	}, this);
};
_s(App, "q7dXTqvL2gJs2ZShKUNbVTeJfA8=", false, function() {
	return [useAnecdotes];
});
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/takahashishuuta/Desktop/Script/FullStack/part6fprsubmission/query-anecdotes/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/takahashishuuta/Desktop/Script/FullStack/part6fprsubmission/query-anecdotes/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/takahashishuuta/Desktop/Script/FullStack/part6fprsubmission/query-anecdotes/src/App.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxrQkFBa0I7QUFDekIsT0FBTyxrQkFBa0I7QUFDekIsU0FBUyxvQkFBb0I7Ozs7OztBQUk3QixNQUFNLFlBQVk7O0NBRWhCLE1BQU0sRUFBQyxXQUFVLFdBQVUsaUJBQWdCLGFBQWE7Ozs7Q0FJdEQsSUFBSSxXQUFXO0VBQ2YsT0FBTyx3QkFBQyxPQUFELFlBQUssa0JBQW9COzs7OztDQUNsQztDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUNFLHdCQUFDLE1BQUQsWUFBSSxlQUFnQjs7Ozs7RUFFcEIsd0JBQUMsY0FBRCxDQUFlOzs7OztFQUNmLHdCQUFDLGNBQUQsQ0FBZTs7Ozs7RUFFZCxVQUFVLEtBQUssYUFDZCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRCxZQUFNLFNBQVMsUUFBYTs7OztZQUM1Qix3QkFBQyxPQUFEO0dBQUs7R0FDRSxTQUFTO0dBQ2Qsd0JBQUMsVUFBRDtJQUFRLGVBQWUsYUFBYSxRQUFRO2NBQUc7R0FBWTs7Ozs7RUFDeEQ7Ozs7VUFDRixLQU5LLFNBQVM7Ozs7U0FNZCxDQUNOO0NBQ0U7Ozs7O0FBRVQ7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBcHAuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBBbmVjZG90ZUZvcm0gZnJvbSAnLi9jb21wb25lbnRzL0FuZWNkb3RlRm9ybSdcbmltcG9ydCBOb3RpZmljYXRpb24gZnJvbSAnLi9jb21wb25lbnRzL05vdGlmaWNhdGlvbidcbmltcG9ydCB7IHVzZUFuZWNkb3RlcyB9IGZyb20gJy4vaG9va3MvdXNlQW5lY2RvdGVzJ1xuXG4vLyBBbmVjZG90ZXNcbi8vIGFuZWNkb3Rlc1xuY29uc3QgQXBwID0gKCkgPT4ge1xuXG4gIGNvbnN0IHthbmVjZG90ZXMsaXNQZW5kaW5nLHZvdGVBbmVjZG90ZX0gPSB1c2VBbmVjZG90ZXMoKVxuICAvLyBjb25zdCBoYW5kbGVWb3RlID0gKGFuZWNkb3RlKSA9PiB7XG4gIC8vICAgY29uc29sZS5sb2coJ3ZvdGUnKVxuICAvLyB9XG4gICAgaWYgKGlzUGVuZGluZykge1xuICAgIHJldHVybiA8ZGl2PmxvYWRpbmcgZGF0YS4uLjwvZGl2PlxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGgzPkFuZWNkb3RlIGFwcDwvaDM+XG5cbiAgICAgIDxOb3RpZmljYXRpb24gLz5cbiAgICAgIDxBbmVjZG90ZUZvcm0gLz5cblxuICAgICAge2FuZWNkb3Rlcy5tYXAoKGFuZWNkb3RlKSA9PiAoXG4gICAgICAgIDxkaXYga2V5PXthbmVjZG90ZS5pZH0+XG4gICAgICAgICAgPGRpdj57YW5lY2RvdGUuY29udGVudH08L2Rpdj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgaGFzIHthbmVjZG90ZS52b3Rlc31cbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gdm90ZUFuZWNkb3RlKGFuZWNkb3RlKX0+dm90ZTwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICkpfVxuICAgIDwvZGl2PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcCJdfQ==