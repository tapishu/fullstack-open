import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Statistics.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { userStatisticsGood, userStatisticsNeutral, userStatisticsBad } from "/src/store.js";
var _jsxFileName = "/Users/takahashishuuta/Desktop/Script/FullStack/part6fprsubmission/unicafe/src/components/Statistics.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e42fcefb";
const Statistics = () => {
	//const {good,neutral,bad}=userStatisticsCounters()
	const good = userStatisticsGood();
	const neutral = userStatisticsNeutral();
	const bad = userStatisticsBad();
	const all = good + neutral + bad;
	const average = all === 0 ? 0 : (good - bad) / all;
	const positive = all === 0 ? 0 : good / all * 100;
	return /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", { children: "statistics" }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 17,
		columnNumber: 7
	}, this), /* @__PURE__ */ _jsxDEV("table", { children: /* @__PURE__ */ _jsxDEV("tbody", { children: [
		/* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", { children: "good" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 20,
			columnNumber: 15
		}, this), /* @__PURE__ */ _jsxDEV("td", { children: good }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 20,
			columnNumber: 28
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 20,
			columnNumber: 11
		}, this),
		/* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", { children: "neutral" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 15
		}, this), /* @__PURE__ */ _jsxDEV("td", { children: neutral }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 31
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 11
		}, this),
		/* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", { children: "bad" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 22,
			columnNumber: 15
		}, this), /* @__PURE__ */ _jsxDEV("td", { children: bad }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 22,
			columnNumber: 27
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 22,
			columnNumber: 11
		}, this),
		/* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", { children: "all" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 15
		}, this), /* @__PURE__ */ _jsxDEV("td", { children: all }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 27
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 11
		}, this),
		/* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", { children: "average" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 24,
			columnNumber: 15
		}, this), /* @__PURE__ */ _jsxDEV("td", { children: average }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 24,
			columnNumber: 31
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 24,
			columnNumber: 11
		}, this),
		/* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", { children: "positive" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 25,
			columnNumber: 15
		}, this), /* @__PURE__ */ _jsxDEV("td", { children: [positive, " %"] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 25,
			columnNumber: 32
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 25,
			columnNumber: 11
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 19,
		columnNumber: 9
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 18,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 16,
		columnNumber: 5
	}, this);
};
_c = Statistics;
export default Statistics;
var _c;
$RefreshReg$(_c, "Statistics");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Statistics.jsx?t=1791134564189";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/takahashishuuta/Desktop/Script/FullStack/part6fprsubmission/unicafe/src/components/Statistics.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/takahashishuuta/Desktop/Script/FullStack/part6fprsubmission/unicafe/src/components/Statistics.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/takahashishuuta/Desktop/Script/FullStack/part6fprsubmission/unicafe/src/components/Statistics.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUSxvQkFBb0IsdUJBQXNCLHlCQUF1Qjs7O0FBR3pFLE1BQU0sbUJBQW1COztDQUV2QixNQUFNLE9BQU8sbUJBQW1CO0NBQ2hDLE1BQU0sVUFBVSxzQkFBc0I7Q0FDdEMsTUFBTSxNQUFNLGtCQUFrQjtDQUc5QixNQUFNLE1BQU0sT0FBSyxVQUFRO0NBQ3pCLE1BQU0sVUFBVSxRQUFRLElBQUksS0FBSSxPQUFLLE9BQUs7Q0FDMUMsTUFBTSxXQUFXLFFBQVEsSUFBSSxJQUFHLE9BQUssTUFBSztDQUUxQyxPQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFELFlBQUksYUFBYzs7OztXQUNsQix3QkFBQyxTQUFELFlBQ0Usd0JBQUMsU0FBRDtFQUNFLHdCQUFDLE1BQUQsYUFBSSx3QkFBQyxNQUFELFlBQUksT0FBUTs7OztZQUFDLHdCQUFDLE1BQUQsWUFBSyxLQUFTOzs7O1VBQUs7Ozs7O0VBQ3BDLHdCQUFDLE1BQUQsYUFBSSx3QkFBQyxNQUFELFlBQUksVUFBVzs7OztZQUFDLHdCQUFDLE1BQUQsWUFBSyxRQUFZOzs7O1VBQUs7Ozs7O0VBQzFDLHdCQUFDLE1BQUQsYUFBSSx3QkFBQyxNQUFELFlBQUksTUFBTzs7OztZQUFDLHdCQUFDLE1BQUQsWUFBSyxJQUFROzs7O1VBQUs7Ozs7O0VBQ2xDLHdCQUFDLE1BQUQsYUFBSSx3QkFBQyxNQUFELFlBQUksTUFBTzs7OztZQUFDLHdCQUFDLE1BQUQsWUFBSyxJQUFROzs7O1VBQUs7Ozs7O0VBQ2xDLHdCQUFDLE1BQUQsYUFBSSx3QkFBQyxNQUFELFlBQUksVUFBVzs7OztZQUFDLHdCQUFDLE1BQUQsWUFBSyxRQUFZOzs7O1VBQUs7Ozs7O0VBQzFDLHdCQUFDLE1BQUQsYUFBSSx3QkFBQyxNQUFELFlBQUksV0FBWTs7OztZQUFDLHdCQUFDLE1BQUQsYUFBSyxVQUFTLElBQU07Ozs7VUFBSzs7Ozs7Q0FDekM7Ozs7VUFDRjs7OztTQUNKOzs7OztBQUVUOztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiU3RhdGlzdGljcy5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHt1c2VyU3RhdGlzdGljc0dvb2QsIHVzZXJTdGF0aXN0aWNzTmV1dHJhbCx1c2VyU3RhdGlzdGljc0JhZH0gZnJvbVwiLi4vc3RvcmVcIlxuXG5cbmNvbnN0IFN0YXRpc3RpY3MgPSAoKSA9PiB7XG4gIC8vY29uc3Qge2dvb2QsbmV1dHJhbCxiYWR9PXVzZXJTdGF0aXN0aWNzQ291bnRlcnMoKVxuICBjb25zdCBnb29kID0gdXNlclN0YXRpc3RpY3NHb29kKClcbiAgY29uc3QgbmV1dHJhbCA9IHVzZXJTdGF0aXN0aWNzTmV1dHJhbCgpXG4gIGNvbnN0IGJhZCA9IHVzZXJTdGF0aXN0aWNzQmFkKClcblxuXG4gIGNvbnN0IGFsbCA9IGdvb2QrbmV1dHJhbCtiYWRcbiAgY29uc3QgYXZlcmFnZSA9IGFsbCA9PT0gMCA/IDAgOihnb29kLWJhZCkvYWxsXG4gIGNvbnN0IHBvc2l0aXZlID0gYWxsID09PSAwID8gMDooZ29vZC9hbGwpKjEwMFxuICBcbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGgyPnN0YXRpc3RpY3M8L2gyPlxuICAgICAgPHRhYmxlPlxuICAgICAgICA8dGJvZHk+XG4gICAgICAgICAgPHRyPjx0ZD5nb29kPC90ZD48dGQ+e2dvb2R9PC90ZD48L3RyPlxuICAgICAgICAgIDx0cj48dGQ+bmV1dHJhbDwvdGQ+PHRkPntuZXV0cmFsfTwvdGQ+PC90cj5cbiAgICAgICAgICA8dHI+PHRkPmJhZDwvdGQ+PHRkPntiYWR9PC90ZD48L3RyPlxuICAgICAgICAgIDx0cj48dGQ+YWxsPC90ZD48dGQ+e2FsbH08L3RkPjwvdHI+XG4gICAgICAgICAgPHRyPjx0ZD5hdmVyYWdlPC90ZD48dGQ+e2F2ZXJhZ2V9PC90ZD48L3RyPlxuICAgICAgICAgIDx0cj48dGQ+cG9zaXRpdmU8L3RkPjx0ZD57cG9zaXRpdmV9ICU8L3RkPjwvdHI+XG4gICAgICAgIDwvdGJvZHk+XG4gICAgICA8L3RhYmxlPlxuICAgIDwvZGl2PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IFN0YXRpc3RpY3NcbiJdfQ==