import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Statistics.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { userStatisticsGood, userStatisticsNeutral, userStatisticsBad } from "/src/store.js";
var _jsxFileName = "/Users/takahashishuuta/Desktop/Script/FullStack/part6fprsubmission/unicafe/src/components/Statistics.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e42fcefb";
const Statistics = () => {
	//const {good,neutral,bad}=userStatisticsCounters()
	const good = userStatisticsGood();
	const neutral = userStatisticsNeutral();
	const bad = userStatisticsBad();
	const all = good + neutral + bad;
	const average = all === 0 ? 0 : (good - bad) / all;
	const positive = all === 0 ? 0 : good / all * 100;
	return /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", { children: "statistics" }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 17,
		columnNumber: 7
	}, this), /* @__PURE__ */ _jsxDEV("table", { children: /* @__PURE__ */ _jsxDEV("tbody", { children: [
		/* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", { children: "good" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 20,
			columnNumber: 15
		}, this), /* @__PURE__ */ _jsxDEV("td", { children: good }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 20,
			columnNumber: 28
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 20,
			columnNumber: 11
		}, this),
		/* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", { children: "neutral" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 15
		}, this), /* @__PURE__ */ _jsxDEV("td", { children: neutral }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 31
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 11
		}, this),
		/* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", { children: "bad" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 22,
			columnNumber: 15
		}, this), /* @__PURE__ */ _jsxDEV("td", { children: bad }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 22,
			columnNumber: 27
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 22,
			columnNumber: 11
		}, this),
		/* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", { children: "all" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 15
		}, this), /* @__PURE__ */ _jsxDEV("td", { children: all }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 27
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 11
		}, this),
		/* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", { children: "average" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 24,
			columnNumber: 15
		}, this), /* @__PURE__ */ _jsxDEV("td", { children: average }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 24,
			columnNumber: 31
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 24,
			columnNumber: 11
		}, this),
		/* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", { children: "positive" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 25,
			columnNumber: 15
		}, this), /* @__PURE__ */ _jsxDEV("td", { children: positive }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 25,
			columnNumber: 32
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 25,
			columnNumber: 11
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 19,
		columnNumber: 9
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 18,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 16,
		columnNumber: 5
	}, this);
};
_c = Statistics;
export default Statistics;
var _c;
$RefreshReg$(_c, "Statistics");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Statistics.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/takahashishuuta/Desktop/Script/FullStack/part6fprsubmission/unicafe/src/components/Statistics.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/takahashishuuta/Desktop/Script/FullStack/part6fprsubmission/unicafe/src/components/Statistics.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/takahashishuuta/Desktop/Script/FullStack/part6fprsubmission/unicafe/src/components/Statistics.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUSxvQkFBb0IsdUJBQXNCLHlCQUF1Qjs7O0FBR3pFLE1BQU0sbUJBQW1COztDQUV2QixNQUFNLE9BQU8sbUJBQW1CO0NBQ2hDLE1BQU0sVUFBVSxzQkFBc0I7Q0FDdEMsTUFBTSxNQUFNLGtCQUFrQjtDQUc5QixNQUFNLE1BQU0sT0FBSyxVQUFRO0NBQ3pCLE1BQU0sVUFBVSxRQUFRLElBQUksS0FBSSxPQUFLLE9BQUs7Q0FDMUMsTUFBTSxXQUFXLFFBQVEsSUFBSSxJQUFHLE9BQUssTUFBSztDQUUxQyxPQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFELFlBQUksYUFBYzs7OztXQUNsQix3QkFBQyxTQUFELFlBQ0Usd0JBQUMsU0FBRDtFQUNFLHdCQUFDLE1BQUQsYUFBSSx3QkFBQyxNQUFELFlBQUksT0FBUTs7OztZQUFDLHdCQUFDLE1BQUQsWUFBSyxLQUFTOzs7O1VBQUs7Ozs7O0VBQ3BDLHdCQUFDLE1BQUQsYUFBSSx3QkFBQyxNQUFELFlBQUksVUFBVzs7OztZQUFDLHdCQUFDLE1BQUQsWUFBSyxRQUFZOzs7O1VBQUs7Ozs7O0VBQzFDLHdCQUFDLE1BQUQsYUFBSSx3QkFBQyxNQUFELFlBQUksTUFBTzs7OztZQUFDLHdCQUFDLE1BQUQsWUFBSyxJQUFROzs7O1VBQUs7Ozs7O0VBQ2xDLHdCQUFDLE1BQUQsYUFBSSx3QkFBQyxNQUFELFlBQUksTUFBTzs7OztZQUFDLHdCQUFDLE1BQUQsWUFBSyxJQUFROzs7O1VBQUs7Ozs7O0VBQ2xDLHdCQUFDLE1BQUQsYUFBSSx3QkFBQyxNQUFELFlBQUksVUFBVzs7OztZQUFDLHdCQUFDLE1BQUQsWUFBSyxRQUFZOzs7O1VBQUs7Ozs7O0VBQzFDLHdCQUFDLE1BQUQsYUFBSSx3QkFBQyxNQUFELFlBQUksV0FBWTs7OztZQUFDLHdCQUFDLE1BQUQsWUFBSyxTQUFhOzs7O1VBQUs7Ozs7O0NBQ3ZDOzs7O1VBQ0Y7Ozs7U0FDSjs7Ozs7QUFFVDs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlN0YXRpc3RpY3MuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7dXNlclN0YXRpc3RpY3NHb29kLCB1c2VyU3RhdGlzdGljc05ldXRyYWwsdXNlclN0YXRpc3RpY3NCYWR9IGZyb21cIi4uL3N0b3JlXCJcblxuXG5jb25zdCBTdGF0aXN0aWNzID0gKCkgPT4ge1xuICAvL2NvbnN0IHtnb29kLG5ldXRyYWwsYmFkfT11c2VyU3RhdGlzdGljc0NvdW50ZXJzKClcbiAgY29uc3QgZ29vZCA9IHVzZXJTdGF0aXN0aWNzR29vZCgpXG4gIGNvbnN0IG5ldXRyYWwgPSB1c2VyU3RhdGlzdGljc05ldXRyYWwoKVxuICBjb25zdCBiYWQgPSB1c2VyU3RhdGlzdGljc0JhZCgpXG5cblxuICBjb25zdCBhbGwgPSBnb29kK25ldXRyYWwrYmFkXG4gIGNvbnN0IGF2ZXJhZ2UgPSBhbGwgPT09IDAgPyAwIDooZ29vZC1iYWQpL2FsbFxuICBjb25zdCBwb3NpdGl2ZSA9IGFsbCA9PT0gMCA/IDA6KGdvb2QvYWxsKSoxMDBcbiAgXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxoMj5zdGF0aXN0aWNzPC9oMj5cbiAgICAgIDx0YWJsZT5cbiAgICAgICAgPHRib2R5PlxuICAgICAgICAgIDx0cj48dGQ+Z29vZDwvdGQ+PHRkPntnb29kfTwvdGQ+PC90cj5cbiAgICAgICAgICA8dHI+PHRkPm5ldXRyYWw8L3RkPjx0ZD57bmV1dHJhbH08L3RkPjwvdHI+XG4gICAgICAgICAgPHRyPjx0ZD5iYWQ8L3RkPjx0ZD57YmFkfTwvdGQ+PC90cj5cbiAgICAgICAgICA8dHI+PHRkPmFsbDwvdGQ+PHRkPnthbGx9PC90ZD48L3RyPlxuICAgICAgICAgIDx0cj48dGQ+YXZlcmFnZTwvdGQ+PHRkPnthdmVyYWdlfTwvdGQ+PC90cj5cbiAgICAgICAgICA8dHI+PHRkPnBvc2l0aXZlPC90ZD48dGQ+e3Bvc2l0aXZlfTwvdGQ+PC90cj5cbiAgICAgICAgPC90Ym9keT5cbiAgICAgIDwvdGFibGU+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgU3RhdGlzdGljc1xuIl19