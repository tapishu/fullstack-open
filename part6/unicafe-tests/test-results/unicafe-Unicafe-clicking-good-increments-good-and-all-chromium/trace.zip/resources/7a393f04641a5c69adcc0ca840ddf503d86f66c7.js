import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Buttons.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { userStatisticsControls } from "/src/store.js";
var _jsxFileName = "/Users/takahashishuuta/Desktop/Script/FullStack/part6fprsubmission/unicafe/src/components/Buttons.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e42fcefb";
const Buttons = () => {
	const { incrementGood, incrementNeutral, incrementBad } = userStatisticsControls();
	return /* @__PURE__ */ _jsxDEV("div", { children: [
		/* @__PURE__ */ _jsxDEV("h2", { children: "give feedback" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 8,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("button", {
			onClick: incrementGood,
			children: "good"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 9,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("button", {
			onClick: incrementNeutral,
			children: "neutral"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 10,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("button", {
			onClick: incrementBad,
			children: "bad"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 11,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 7,
		columnNumber: 5
	}, this);
};
_c = Buttons;
export default Buttons;
var _c;
$RefreshReg$(_c, "Buttons");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Buttons.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/takahashishuuta/Desktop/Script/FullStack/part6fprsubmission/unicafe/src/components/Buttons.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/takahashishuuta/Desktop/Script/FullStack/part6fprsubmission/unicafe/src/components/Buttons.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/takahashishuuta/Desktop/Script/FullStack/part6fprsubmission/unicafe/src/components/Buttons.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUSw4QkFBNEI7OztBQUVwQyxNQUFNLGdCQUFnQjtDQUVwQixNQUFNLEVBQUMsZUFBYyxrQkFBaUIsaUJBQWdCLHVCQUF1QjtDQUM3RSxPQUNFLHdCQUFDLE9BQUQ7RUFDRSx3QkFBQyxNQUFELFlBQUksZ0JBQWlCOzs7OztFQUNyQix3QkFBQyxVQUFEO0dBQVEsU0FBUzthQUFlO0VBQVk7Ozs7O0VBQzVDLHdCQUFDLFVBQUQ7R0FBUSxTQUFTO2FBQWtCO0VBQWU7Ozs7O0VBQ2xELHdCQUFDLFVBQUQ7R0FBUSxTQUFTO2FBQWM7RUFBVzs7Ozs7Q0FDdkM7Ozs7O0FBRVQ7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJCdXR0b25zLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge3VzZXJTdGF0aXN0aWNzQ29udHJvbHN9IGZyb21cIi4uL3N0b3JlXCJcblxuY29uc3QgQnV0dG9ucyA9ICgpID0+IHtcblxuICBjb25zdCB7aW5jcmVtZW50R29vZCxpbmNyZW1lbnROZXV0cmFsLGluY3JlbWVudEJhZH0gPSB1c2VyU3RhdGlzdGljc0NvbnRyb2xzKClcbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGgyPmdpdmUgZmVlZGJhY2s8L2gyPlxuICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtpbmNyZW1lbnRHb29kfT5nb29kPC9idXR0b24+XG4gICAgICA8YnV0dG9uIG9uQ2xpY2s9e2luY3JlbWVudE5ldXRyYWx9Pm5ldXRyYWw8L2J1dHRvbj5cbiAgICAgIDxidXR0b24gb25DbGljaz17aW5jcmVtZW50QmFkfT5iYWQ8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBCdXR0b25zXG4iXX0=