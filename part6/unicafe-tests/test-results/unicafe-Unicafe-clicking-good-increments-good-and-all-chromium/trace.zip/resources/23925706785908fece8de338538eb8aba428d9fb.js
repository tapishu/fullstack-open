//import { useShallow } from "zustand/react/shallow"
import { create } from "/node_modules/.vite/deps/zustand.js?v=e42fcefb";
const usesStatisticsStore = create((set) => ({
	good: 0,
	neutral: 0,
	bad: 0,
	// all: good + neutral + bad,
	// average: 1,
	// positibe:1,
	actions: {
		incrementGood: () => set((state) => ({ good: state.good + 1 })),
		incrementNeutral: () => set((state) => ({ neutral: state.neutral + 1 })),
		incrementBad: () => set((state) => ({ bad: state.bad + 1 }))
	}
}));
//export const userStatisticsCounters = ()=> usesStatisticsStore(state=>state.counters)
export const userStatisticsGood = () => usesStatisticsStore((state) => state.good);
export const userStatisticsNeutral = () => usesStatisticsStore((state) => state.neutral);
export const userStatisticsBad = () => usesStatisticsStore((state) => state.bad);
export const userStatisticsControls = () => usesStatisticsStore((state) => state.actions);

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IjtBQUNBLFNBQVMsY0FBYztBQUV2QixNQUFNLHNCQUFxQixRQUFPLFNBQU87Q0FFekMsTUFBSztDQUNMLFNBQVE7Q0FDUixLQUFJOzs7O0NBS0osU0FBUTtFQUNSLHFCQUFvQixLQUFJLFdBQVMsRUFDN0IsTUFBSyxNQUFNLE9BQU8sRUFDdEIsRUFBRTtFQUNGLHdCQUFzQixLQUFJLFdBQVMsRUFDL0IsU0FBUSxNQUFNLFVBQVUsRUFDNUIsRUFBRTtFQUNGLG9CQUFrQixLQUFJLFdBQVMsRUFDM0IsS0FBSSxNQUFNLE1BQU0sRUFDcEIsRUFBRTtDQUNGO0FBRUEsRUFBRTs7QUFFRixPQUFPLE1BQU0sMkJBQTBCLHFCQUFvQixVQUFPLE1BQU0sSUFBSTtBQUM1RSxPQUFPLE1BQU0sOEJBQTZCLHFCQUFvQixVQUFPLE1BQU0sT0FBTztBQUNsRixPQUFPLE1BQU0sMEJBQXlCLHFCQUFvQixVQUFPLE1BQU0sR0FBRztBQUUxRSxPQUFPLE1BQU0sK0JBQThCLHFCQUFvQixVQUFPLE1BQU0sT0FBTyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJzdG9yZS5qcyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvL2ltcG9ydCB7IHVzZVNoYWxsb3cgfSBmcm9tIFwienVzdGFuZC9yZWFjdC9zaGFsbG93XCJcbmltcG9ydCB7IGNyZWF0ZSB9IGZyb20gJ3p1c3RhbmQnXG5cbmNvbnN0IHVzZXNTdGF0aXN0aWNzU3RvcmU9IGNyZWF0ZShzZXQgPT4oe1xuXG5nb29kOjAsXG5uZXV0cmFsOjAsXG5iYWQ6MCxcblxuLy8gYWxsOiBnb29kICsgbmV1dHJhbCArIGJhZCxcbi8vIGF2ZXJhZ2U6IDEsXG4vLyBwb3NpdGliZToxLFxuYWN0aW9uczp7XG5pbmNyZW1lbnRHb29kOiAoKT0+IHNldChzdGF0ZSA9Pih7XG4gICAgZ29vZDpzdGF0ZS5nb29kICsgMVxufSkpLFxuaW5jcmVtZW50TmV1dHJhbDooKT0+IHNldChzdGF0ZSA9Pih7XG4gICAgbmV1dHJhbDpzdGF0ZS5uZXV0cmFsICsgMVxufSkpLFxuaW5jcmVtZW50QmFkOigpPT4gc2V0KHN0YXRlID0+KHtcbiAgICBiYWQ6c3RhdGUuYmFkICsgMVxufSkpXG59XG5cbn0pKVxuLy9leHBvcnQgY29uc3QgdXNlclN0YXRpc3RpY3NDb3VudGVycyA9ICgpPT4gdXNlc1N0YXRpc3RpY3NTdG9yZShzdGF0ZT0+c3RhdGUuY291bnRlcnMpXG5leHBvcnQgY29uc3QgdXNlclN0YXRpc3RpY3NHb29kID0gKCk9PiB1c2VzU3RhdGlzdGljc1N0b3JlKHN0YXRlPT5zdGF0ZS5nb29kKVxuZXhwb3J0IGNvbnN0IHVzZXJTdGF0aXN0aWNzTmV1dHJhbCA9ICgpPT4gdXNlc1N0YXRpc3RpY3NTdG9yZShzdGF0ZT0+c3RhdGUubmV1dHJhbClcbmV4cG9ydCBjb25zdCB1c2VyU3RhdGlzdGljc0JhZCA9ICgpPT4gdXNlc1N0YXRpc3RpY3NTdG9yZShzdGF0ZT0+c3RhdGUuYmFkKVxuXG5leHBvcnQgY29uc3QgdXNlclN0YXRpc3RpY3NDb250cm9scyA9ICgpPT4gdXNlc1N0YXRpc3RpY3NTdG9yZShzdGF0ZT0+c3RhdGUuYWN0aW9ucykiXX0=