import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f4884521"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/Blog.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=f4884521"; const useState = __vite__cjsImport3_react["useState"];
import { Container, Toolbar } from "/node_modules/.vite/deps/@mui_material.js?v=93970f84";
import { Alert, AppBar, Button, Paper } from "/node_modules/.vite/deps/@mui_material.js?v=93970f84";
const Blog = ({ blog, handleLike, handleRemove, currentUser }) => {
  if (!blog) {
    return null;
  }
  const blogStyle = {
    paddingTop: 10,
    paddingLeft: 2,
    border: "solid",
    borderWidth: 1,
    marginBottom: 5
  };
  const showRemoveButton = blog.user && currentUser && blog.user.username === currentUser.username;
  return /* @__PURE__ */ jsxDEV(Paper, { elevation: 1, style: { padding: 24, marginTop: 20, marginBottom: 20 }, children: [
    /* @__PURE__ */ jsxDEV("h2", { style: { marginTop: 0, marginBottom: 8 }, children: blog.title }, void 0, false, {
      fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 49,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { color: "#555", marginBottom: 12, fontSize: "1.1rem" }, children: [
      "by ",
      blog.author
    ] }, void 0, true, {
      fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 55,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("a", { href: blog.url, target: "_blank", rel: "noopener noreferrer", children: blog.url }, void 0, false, {
      fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 59,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 58,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { color: "#666", marginBottom: 16 }, children: [
      "Added by ",
      blog.user?.name || blog.user?.username
    ] }, void 0, true, {
      fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 63,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", gap: 12 }, children: [
      /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: "bold" }, children: [
        blog.likes,
        " likes"
      ] }, void 0, true, {
        fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 67,
        columnNumber: 11
      }, this),
      currentUser && /* @__PURE__ */ jsxDEV(Button, { variant: "outlined", color: "primary", onClick: handleLike, children: "like" }, void 0, false, {
        fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 70,
        columnNumber: 9
      }, this),
      showRemoveButton && /* @__PURE__ */ jsxDEV(Button, { variant: "outlined", color: "error", onClick: handleRemove, children: "remove" }, void 0, false, {
        fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 74,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 66,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/Blog.jsx",
    lineNumber: 48,
    columnNumber: 5
  }, this);
};
_c = Blog;
export default Blog;
var _c;
$RefreshReg$(_c, "Blog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/Blog.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkJROzs7Ozs7Ozs7Ozs7Ozs7O0FBN0JSLFNBQVNBLGdCQUFnQjtBQUN6QixTQUFTQyxXQUFXQyxlQUFlO0FBQ25DLFNBQVNDLE9BQU1DLFFBQU9DLFFBQU9DLGFBQWE7QUFDMUMsTUFBTUMsT0FBT0EsQ0FBQyxFQUFFQyxNQUFNQyxZQUFZQyxjQUFhQyxZQUFZLE1BQU07QUFHL0QsTUFBSSxDQUFDSCxNQUFNO0FBQ1QsV0FBTztBQUFBLEVBQ1Q7QUFFQSxRQUFNSSxZQUFZO0FBQUEsSUFDaEJDLFlBQVk7QUFBQSxJQUNaQyxhQUFhO0FBQUEsSUFDYkMsUUFBUTtBQUFBLElBQ1JDLGFBQWE7QUFBQSxJQUNiQyxjQUFjO0FBQUEsRUFDaEI7QUFNQSxRQUFNQyxtQkFDSlYsS0FBS1csUUFDTFIsZUFDQ0gsS0FBS1csS0FBS0MsYUFBYVQsWUFBWVM7QUFFdEMsU0FDRix1QkFBQyxTQUFNLFdBQVcsR0FBRyxPQUFPLEVBQUVDLFNBQVMsSUFBSUMsV0FBVyxJQUFJTCxjQUFjLEdBQUcsR0FDbkU7QUFBQSwyQkFBQyxRQUFHLE9BQU8sRUFBRUssV0FBVyxHQUFHTCxjQUFjLEVBQUMsR0FDekNULGVBQUtlLFNBRE47QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtGO0FBQUEsSUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRUMsT0FBTyxRQUFRUCxjQUFjLElBQUlRLFVBQVUsU0FBUyxHQUFFO0FBQUE7QUFBQSxNQUM3RGpCLEtBQUtrQjtBQUFBQSxTQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0UsdUJBQUMsU0FDQyxpQ0FBQyxPQUFFLE1BQU1sQixLQUFLbUIsS0FBSyxRQUFPLFVBQVMsS0FBSSx1QkFDdENuQixlQUFLbUIsT0FETjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUYsS0FIQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFSCxPQUFPLFFBQVFQLGNBQWMsR0FBRyxHQUFFO0FBQUE7QUFBQSxNQUNwQ1QsS0FBS1csTUFBTVMsUUFBUXBCLEtBQUtXLE1BQU1DO0FBQUFBLFNBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFRTtBQUFBLElBQ0YsdUJBQUMsU0FBSSxPQUFPLEVBQUVTLFNBQVMsUUFBUUMsWUFBWSxVQUFVQyxLQUFLLEdBQUcsR0FDM0Q7QUFBQSw2QkFBQyxVQUFLLE9BQU8sRUFBRUMsWUFBWSxPQUFPLEdBQUl4QjtBQUFBQSxhQUFLeUI7QUFBQUEsUUFBTTtBQUFBLFdBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUQ7QUFBQSxNQUV0RHRCLGVBQ0MsdUJBQUMsVUFBTyxTQUFRLFlBQVcsT0FBTSxXQUFVLFNBQVNGLFlBQVcsb0JBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFRjtBQUFBLE1BQ0RTLG9CQUNULHVCQUFDLFVBQU8sU0FBUSxZQUFXLE9BQU0sU0FBUSxTQUFTUixjQUFhLHNCQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRVU7QUFBQSxTQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXRjtBQUFBLE9BN0JOO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErQkk7QUFFSjtBQUFDd0IsS0ExREszQjtBQTJETixlQUFlQTtBQUFJLElBQUEyQjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkNvbnRhaW5lciIsIlRvb2xiYXIiLCJBbGVydCIsIkFwcEJhciIsIkJ1dHRvbiIsIlBhcGVyIiwiQmxvZyIsImJsb2ciLCJoYW5kbGVMaWtlIiwiaGFuZGxlUmVtb3ZlIiwiY3VycmVudFVzZXIiLCJibG9nU3R5bGUiLCJwYWRkaW5nVG9wIiwicGFkZGluZ0xlZnQiLCJib3JkZXIiLCJib3JkZXJXaWR0aCIsIm1hcmdpbkJvdHRvbSIsInNob3dSZW1vdmVCdXR0b24iLCJ1c2VyIiwidXNlcm5hbWUiLCJwYWRkaW5nIiwibWFyZ2luVG9wIiwidGl0bGUiLCJjb2xvciIsImZvbnRTaXplIiwiYXV0aG9yIiwidXJsIiwibmFtZSIsImRpc3BsYXkiLCJhbGlnbkl0ZW1zIiwiZ2FwIiwiZm9udFdlaWdodCIsImxpa2VzIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQmxvZy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IENvbnRhaW5lciwgVG9vbGJhciB9IGZyb20gJ0BtdWkvbWF0ZXJpYWwnXG5pbXBvcnQgeyBBbGVydCxBcHBCYXIsQnV0dG9uLFBhcGVyIH0gZnJvbSAnQG11aS9tYXRlcmlhbCdcbmNvbnN0IEJsb2cgPSAoeyBibG9nLCBoYW5kbGVMaWtlLCBoYW5kbGVSZW1vdmUsY3VycmVudFVzZXIgfSkgPT4ge1xuXG5cbiAgaWYgKCFibG9nKSB7XG4gICAgcmV0dXJuIG51bGxcbiAgfVxuICAvLyBjb25zdCBbdmlzaWJsZSwgc2V0VmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgYmxvZ1N0eWxlID0ge1xuICAgIHBhZGRpbmdUb3A6IDEwLFxuICAgIHBhZGRpbmdMZWZ0OiAyLFxuICAgIGJvcmRlcjogJ3NvbGlkJyxcbiAgICBib3JkZXJXaWR0aDogMSxcbiAgICBtYXJnaW5Cb3R0b206IDVcbiAgfVxuXG4gIC8vIGNvbnN0IHRvZ2dsZVZpc2liaWxpdHkgPSAoKSA9PiB7XG4gIC8vICAgc2V0VmlzaWJsZSghdmlzaWJsZSlcbiAgLy8gfVxuXG4gIGNvbnN0IHNob3dSZW1vdmVCdXR0b24gPVxuICAgIGJsb2cudXNlciAmJlxuICAgIGN1cnJlbnRVc2VyICYmXG4gICAgKGJsb2cudXNlci51c2VybmFtZSA9PT0gY3VycmVudFVzZXIudXNlcm5hbWUpXG5cbiAgcmV0dXJuKFxuPFBhcGVyIGVsZXZhdGlvbj17MX0gc3R5bGU9e3sgcGFkZGluZzogMjQsIG1hcmdpblRvcDogMjAsIG1hcmdpbkJvdHRvbTogMjAgfX0+XG4gICAgICAgIDxoMiBzdHlsZT17eyBtYXJnaW5Ub3A6IDAsIG1hcmdpbkJvdHRvbTogOH19PlxuICAgICAgICB7YmxvZy50aXRsZX1cbiAgICAgICAgey8qIDxidXR0b24gb25DbGljaz17dG9nZ2xlVmlzaWJpbGl0eX0+XG4gICAgICAgICAge3Zpc2libGUgPyAnaGlkZScgOiAndmlldyd9XG4gICAgICAgIDwvYnV0dG9uPiAqL31cbiAgICAgIDwvaDI+XG4gICAgICA8ZGl2IHN0eWxlPXt7IGNvbG9yOiAnIzU1NScsIG1hcmdpbkJvdHRvbTogMTIsIGZvbnRTaXplOiAnMS4xcmVtJyB9fT5cbiAgICAgICAgIGJ5IHtibG9nLmF1dGhvcn1cbiAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxhIGhyZWY9e2Jsb2cudXJsfSB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCI+XG4gICAgICAgICAge2Jsb2cudXJsfVxuICAgICAgICA8L2E+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGNvbG9yOiAnIzY2NicsIG1hcmdpbkJvdHRvbTogMTYgfX0+XG4gICAgICAgICAgQWRkZWQgYnkge2Jsb2cudXNlcj8ubmFtZSB8fCBibG9nLnVzZXI/LnVzZXJuYW1lfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGdhcDogMTIgfX0+XG4gICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFdlaWdodDogJ2JvbGQnIH19PntibG9nLmxpa2VzfSBsaWtlczwvc3Bhbj5cblxuICAgICAgICAgIHtjdXJyZW50VXNlciAmJiAoXG4gICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lZFwiIGNvbG9yPVwicHJpbWFyeVwiIG9uQ2xpY2s9e2hhbmRsZUxpa2V9PlxuICAgICAgICAgICAgbGlrZVxuICAgICAgICAgIDwvQnV0dG9uPiAgICAgICAgKX1cbiAgICAgICAge3Nob3dSZW1vdmVCdXR0b24gJiYgKFxuPEJ1dHRvbiB2YXJpYW50PVwib3V0bGluZWRcIiBjb2xvcj1cImVycm9yXCIgb25DbGljaz17aGFuZGxlUmVtb3ZlfT5cbiAgICAgICAgICAgIHJlbW92ZVxuICAgICAgICAgIDwvQnV0dG9uPiAgICAgICAgICApfVxuICAgICAgPC9kaXY+XG4gICAgICB7LyogKX0gKi99XG4gICAgPC9QYXBlcj5cbiAgKVxufVxuZXhwb3J0IGRlZmF1bHQgQmxvZyJdLCJmaWxlIjoiL1VzZXJzL3Rha2FoYXNoaXNodXV0YS9EZXNrdG9wL1NjcmlwdC9GdWxsU3RhY2svcGFydDVmb3JzdWJtaXNzaW9uL2Jsb2dsaXN0LWZyb250ZW5kL3NyYy9jb21wb25lbnRzL0Jsb2cuanN4In0=