import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BlogList.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f4884521"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/BlogList.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=099a5fac";
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper } from "/node_modules/.vite/deps/@mui_material.js?v=93970f84";
const BlogList = ({ blogs }) => {
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "blogs" }, void 0, false, {
      fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/BlogList.jsx",
      lineNumber: 27,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "blog-list", children: blogs.concat().sort((a, b) => b.likes - a.likes).map(
      (blog) => /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(Link, { to: `/blogs/${blog.id}`, children: [
        blog.title,
        " - ",
        blog.author
      ] }, void 0, true, {
        fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/BlogList.jsx",
        lineNumber: 35,
        columnNumber: 15
      }, this) }, blog.id, false, {
        fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/BlogList.jsx",
        lineNumber: 34,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/BlogList.jsx",
      lineNumber: 29,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/BlogList.jsx",
    lineNumber: 26,
    columnNumber: 5
  }, this);
};
_c = BlogList;
export default BlogList;
var _c;
$RefreshReg$(_c, "BlogList");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/BlogList.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/BlogList.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT007Ozs7Ozs7Ozs7Ozs7Ozs7QUFQTixTQUFTQSxZQUFZO0FBQ3JCLFNBQVNDLE9BQU9DLFdBQVdDLFdBQVdDLGdCQUFnQkMsV0FBV0MsVUFBVUMsYUFBYTtBQUV4RixNQUFNQyxXQUFXQSxDQUFDLEVBQUVDLE1BQU0sTUFBTTtBQUU5QixTQUNFLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxRQUFHLHFCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUztBQUFBLElBRVQsdUJBQUMsU0FBSSxXQUFVLGFBQ1pBLGdCQUNFQyxPQUFPLEVBQ1BDLEtBQUssQ0FBQ0MsR0FBRUMsTUFBTUEsRUFBRUMsUUFBUUYsRUFBRUUsS0FBSyxFQUMvQkM7QUFBQUEsTUFBSSxDQUFBQyxTQUNILHVCQUFDLFNBQ0MsaUNBQUMsUUFBSyxJQUFJLFVBQVVBLEtBQUtDLEVBQUUsSUFDeEJEO0FBQUFBLGFBQUtFO0FBQUFBLFFBQU07QUFBQSxRQUFJRixLQUFLRztBQUFBQSxXQUR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsS0FIUUgsS0FBS0MsSUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxJQUNGLEtBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBO0FBQUEsT0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZUE7QUFFSjtBQUFDRyxLQXBCS1o7QUFxQk4sZUFBZUE7QUFBUSxJQUFBWTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJMaW5rIiwiVGFibGUiLCJUYWJsZUJvZHkiLCJUYWJsZUNlbGwiLCJUYWJsZUNvbnRhaW5lciIsIlRhYmxlSGVhZCIsIlRhYmxlUm93IiwiUGFwZXIiLCJCbG9nTGlzdCIsImJsb2dzIiwiY29uY2F0Iiwic29ydCIsImEiLCJiIiwibGlrZXMiLCJtYXAiLCJibG9nIiwiaWQiLCJ0aXRsZSIsImF1dGhvciIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkJsb2dMaXN0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcbmltcG9ydCB7IFRhYmxlLCBUYWJsZUJvZHksIFRhYmxlQ2VsbCwgVGFibGVDb250YWluZXIsIFRhYmxlSGVhZCwgVGFibGVSb3csIFBhcGVyIH0gZnJvbSAnQG11aS9tYXRlcmlhbCdcblxuY29uc3QgQmxvZ0xpc3QgPSAoeyBibG9ncyB9KSA9PiB7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGgyPmJsb2dzPC9oMj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9J2Jsb2ctbGlzdCc+XG4gICAgICAgIHtibG9nc1xuICAgICAgICAgIC5jb25jYXQoKVxuICAgICAgICAgIC5zb3J0KChhLGIpID0+IGIubGlrZXMgLSBhLmxpa2VzKVxuICAgICAgICAgIC5tYXAoYmxvZyA9PlxuICAgICAgICAgICAgPGRpdiBrZXk9e2Jsb2cuaWR9PlxuICAgICAgICAgICAgICA8TGluayB0bz17YC9ibG9ncy8ke2Jsb2cuaWR9YH0+XG4gICAgICAgICAgICAgICAge2Jsb2cudGl0bGV9IC0ge2Jsb2cuYXV0aG9yfVxuICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIClcbn1cbmV4cG9ydCBkZWZhdWx0IEJsb2dMaXN0Il0sImZpbGUiOiIvVXNlcnMvdGFrYWhhc2hpc2h1dXRhL0Rlc2t0b3AvU2NyaXB0L0Z1bGxTdGFjay9wYXJ0NWZvcnN1Ym1pc3Npb24vYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvQmxvZ0xpc3QuanN4In0=