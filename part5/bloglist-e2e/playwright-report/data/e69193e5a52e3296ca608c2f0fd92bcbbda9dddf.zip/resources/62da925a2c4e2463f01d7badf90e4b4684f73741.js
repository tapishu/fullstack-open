import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f4884521"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/App.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=f4884521"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import Blog from "/src/components/Blog.jsx?t=1791066082301";
import blogService from "/src/services/blogs.js";
import loginService from "/src/services/login.js";
import BlogForm from "/src/components/BlogForm.jsx?t=1791062463396";
import Togglable from "/src/components/Togglable.jsx";
import LoginForm from "/src/components/LoginForm.jsx?t=1791066655796";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Link,
  useMatch,
  useNavigate
} from "/node_modules/.vite/deps/react-router-dom.js?v=099a5fac";
import BlogList from "/src/components/BlogList.jsx";
import { Container, Toolbar } from "/node_modules/.vite/deps/@mui_material.js?v=93970f84";
import { Alert, AppBar, Button } from "/node_modules/.vite/deps/@mui_material.js?v=93970f84";
const Notification = ({ notification }) => {
  if (!notification) {
    return null;
  }
  return /* @__PURE__ */ jsxDEV("div", { className: notification.type === "success" ? "success" : "error", children: /* @__PURE__ */ jsxDEV(Alert, { style: { marginTop: 10, marginBottom: 10 }, severity: notification.type, children: notification.message }, void 0, false, {
    fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/App.jsx",
    lineNumber: 45,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/App.jsx",
    lineNumber: 44,
    columnNumber: 5
  }, this);
};
_c = Notification;
const App = () => {
  _s();
  const [blogs, setBlogs] = useState([]);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);
  const [notification, setNotification] = useState(null);
  const blogFormRef = useRef();
  const navigate = useNavigate();
  const notify = (message, type = "success") => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification(null);
    }, 5e4);
  };
  const handleLogin = async (event) => {
    event.preventDefault();
    console.log("logging in with", username, password);
    try {
      const user2 = await loginService.login({ username, password });
      window.localStorage.setItem(
        "loggedBlogappUser",
        JSON.stringify(user2)
      );
      notify("login success", "success");
      blogService.setToken(user2.token);
      setUser(user2);
      setUsername("");
      setPassword("");
      navigate("/");
    } catch {
      notify("wrong credentials", "error");
    }
  };
  useEffect(() => {
    const loggedUserJSON = window.localStorage.getItem("loggedBlogappUser");
    if (loggedUserJSON) {
      const user2 = JSON.parse(loggedUserJSON);
      setUser(user2);
      blogService.setToken(user2.token);
    }
  }, []);
  const handleLogout = (event) => {
    event.preventDefault();
    console.log("log out with", username, password);
    window.localStorage.removeItem("loggedBlogappUser");
    setUser(null);
    blogService.setToken(null);
    notify("logged out", "success");
    navigate("/");
  };
  const handleCreateBlog = async (blogObject) => {
    try {
      const returnedBlog = await blogService.create(blogObject);
      setBlogs(blogs.concat(returnedBlog));
      notify(`a new blog ${returnedBlog.title} by ${returnedBlog.author} added`, "success");
      navigate("/");
    } catch (exception) {
      notify("failed to create blog", "error");
      console.error(exception);
      navigate("/");
    }
  };
  const handleLike = async (blog2) => {
    const updateBlog = {
      user: blog2.user?.id || blog2.user,
      likes: blog2.likes + 1,
      author: blog2.author,
      title: blog2.title,
      url: blog2.url
    };
    try {
      const updatedBlog = await blogService.update(blog2.id, updateBlog);
      setBlogs(blogs.map((b) => b.id === blog2.id ? updatedBlog : b));
    } catch {
      notify("failed to like the blog", "error");
    }
  };
  const handleRemove = async (blog2) => {
    const ok = window.confirm(`Remove blog ${blog2.title} by ${blog2.author}?`);
    if (ok) {
      try {
        await blogService.remove(blog2.id);
        setBlogs(blogs.filter((b) => b.id !== blog2.id));
      } catch {
        notify("failed to remove the blog", "error");
      }
    }
  };
  useEffect(() => {
    blogService.getAll().then(
      (blogs2) => setBlogs(blogs2)
    );
  }, []);
  const match = useMatch("/blogs/:id");
  const blog = match ? blogs.find((b) => b.id === match.params.id) : null;
  return /* @__PURE__ */ jsxDEV(Container, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(AppBar, { position: "static", children: /* @__PURE__ */ jsxDEV(Toolbar, { children: [
      /* @__PURE__ */ jsxDEV("div", { style: { flexGrow: 1, fontSize: "1.25rem", fontWeight: "bold" }, children: "Blog App" }, void 0, false, {
        fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/App.jsx",
        lineNumber: 169,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { color: "inherit", component: Link, to: "/", children: "blogs" }, void 0, false, {
        fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/App.jsx",
        lineNumber: 173,
        columnNumber: 13
      }, this),
      user && /* @__PURE__ */ jsxDEV(Button, { color: "inherit", component: Link, to: "/create", children: "new blog" }, void 0, false, {
        fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/App.jsx",
        lineNumber: 174,
        columnNumber: 22
      }, this),
      user ? /* @__PURE__ */ jsxDEV(Button, { color: "inherit", onClick: handleLogout, children: "logout" }, void 0, false, {
        fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/App.jsx",
        lineNumber: 175,
        columnNumber: 21
      }, this) : /* @__PURE__ */ jsxDEV(Button, { color: "inherit", component: Link, to: "/login", children: "login" }, void 0, false, {
        fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/App.jsx",
        lineNumber: 176,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/App.jsx",
      lineNumber: 168,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/App.jsx",
      lineNumber: 167,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/App.jsx",
      lineNumber: 166,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV(Notification, { notification }, void 0, false, {
        fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/App.jsx",
        lineNumber: 184,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Routes, { children: [
        /* @__PURE__ */ jsxDEV(Route, { path: "/", element: /* @__PURE__ */ jsxDEV(BlogList, { blogs }, void 0, false, {
          fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/App.jsx",
          lineNumber: 187,
          columnNumber: 36
        }, this) }, void 0, false, {
          fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/App.jsx",
          lineNumber: 187,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Route, { path: "/login", element: /* @__PURE__ */ jsxDEV(
          LoginForm,
          {
            username,
            password,
            handleUsernameChange: ({ target }) => setUsername(target.value),
            handlePasswordChange: ({ target }) => setPassword(target.value),
            handleSubmit: handleLogin
          },
          void 0,
          false,
          {
            fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/App.jsx",
            lineNumber: 188,
            columnNumber: 41
          },
          this
        ) }, void 0, false, {
          fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/App.jsx",
          lineNumber: 188,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Route, { path: "/create", element: /* @__PURE__ */ jsxDEV(BlogForm, { createBlog: handleCreateBlog }, void 0, false, {
          fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/App.jsx",
          lineNumber: 195,
          columnNumber: 42
        }, this) }, void 0, false, {
          fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/App.jsx",
          lineNumber: 195,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Route,
          {
            path: "/blogs/:id",
            element: /* @__PURE__ */ jsxDEV(
              Blog,
              {
                blog,
                handleLike: () => handleLike(blog),
                handleRemove: () => handleRemove(blog),
                currentUser: user
              },
              void 0,
              false,
              {
                fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/App.jsx",
                lineNumber: 201,
                columnNumber: 15
              },
              this
            )
          },
          void 0,
          false,
          {
            fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/App.jsx",
            lineNumber: 198,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/App.jsx",
        lineNumber: 186,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/App.jsx",
      lineNumber: 183,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/App.jsx",
    lineNumber: 165,
    columnNumber: 5
  }, this) }, void 0, false, {
    fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/App.jsx",
    lineNumber: 164,
    columnNumber: 5
  }, this);
};
_s(App, "TKNgrZnt4ESZHUA5OjFfsFVA1IU=", false, function() {
  return [useNavigate, useMatch];
});
_c2 = App;
export default App;
var _c, _c2;
$RefreshReg$(_c, "Notification");
$RefreshReg$(_c2, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQXpCTixTQUFTQSxVQUFVQyxXQUFVQyxjQUFjO0FBQzNDLE9BQU9DLFVBQVU7QUFDakIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxjQUFjO0FBQ3JCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsZUFBZTtBQUN0QjtBQUFBLEVBQ0VDLGlCQUFpQkM7QUFBQUEsRUFDakJDO0FBQUFBLEVBQVFDO0FBQUFBLEVBQU9DO0FBQUFBLEVBQU1DO0FBQUFBLEVBQVNDO0FBQUFBLE9BQ3pCO0FBQ1AsT0FBT0MsY0FBYztBQUNyQixTQUFTQyxXQUFXQyxlQUFlO0FBQ25DLFNBQVNDLE9BQU1DLFFBQU9DLGNBQWM7QUFNcEMsTUFBTUMsZUFBZUEsQ0FBQyxFQUFFQyxhQUFhLE1BQU07QUFDekMsTUFBSSxDQUFDQSxjQUFjO0FBQ2pCLFdBQU87QUFBQSxFQUNUO0FBQ0EsU0FDRSx1QkFBQyxTQUFJLFdBQVdBLGFBQWFDLFNBQVMsWUFBWSxZQUFZLFNBQzVELGlDQUFDLFNBQU0sT0FBTyxFQUFDQyxXQUFXLElBQUlDLGNBQWMsR0FBRSxHQUFHLFVBQVVILGFBQWFDLE1BQ3ZFRCx1QkFBYUksV0FEZDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBSUE7QUFFSjtBQUFDQyxLQVhLTjtBQWFOLE1BQU1PLE1BQU1BLE1BQU07QUFBQUMsS0FBQTtBQUNoQixRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSWhDLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNpQyxVQUFVQyxXQUFXLElBQUlsQyxTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDbUMsVUFBVUMsV0FBVyxJQUFJcEMsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ3FDLE1BQU1DLE9BQU8sSUFBSXRDLFNBQVMsSUFBSTtBQUNyQyxRQUFNLENBQUN1QixjQUFjZ0IsZUFBZSxJQUFJdkMsU0FBUyxJQUFJO0FBQ3JELFFBQU13QyxjQUFjdEMsT0FBTztBQUMzQixRQUFNdUMsV0FBVzFCLFlBQVk7QUFFN0IsUUFBTTJCLFNBQVNBLENBQUNmLFNBQVNILE9BQU8sY0FBYztBQUM1Q2Usb0JBQWdCLEVBQUVaLFNBQVNILEtBQUssQ0FBQztBQUNqQ21CLGVBQVcsTUFBTTtBQUNmSixzQkFBZ0IsSUFBSTtBQUFBLElBQ3RCLEdBQUcsR0FBSztBQUFBLEVBQ1Y7QUFDQSxRQUFNSyxjQUFjLE9BQU9DLFVBQVU7QUFDbkNBLFVBQU1DLGVBQWU7QUFDckJDLFlBQVFDLElBQUksbUJBQW1CZixVQUFVRSxRQUFRO0FBRWpELFFBQUc7QUFDRCxZQUFNRSxRQUFPLE1BQU1oQyxhQUFhNEMsTUFBTSxFQUFFaEIsVUFBU0UsU0FBUyxDQUFDO0FBQzNEZSxhQUFPQyxhQUFhQztBQUFBQSxRQUNsQjtBQUFBLFFBQXFCQyxLQUFLQyxVQUFVakIsS0FBSTtBQUFBLE1BQzFDO0FBQ0FLLGFBQU8saUJBQWlCLFNBQVM7QUFDakN0QyxrQkFBWW1ELFNBQVNsQixNQUFLbUIsS0FBSztBQUMvQmxCLGNBQVFELEtBQUk7QUFDWkgsa0JBQVksRUFBRTtBQUNkRSxrQkFBWSxFQUFFO0FBQ2RLLGVBQVMsR0FBRztBQUFBLElBQ2QsUUFBUTtBQUNOQyxhQUFPLHFCQUFxQixPQUFPO0FBQUEsSUFDckM7QUFBQSxFQUNGO0FBSUF6QyxZQUFVLE1BQU07QUFDZCxVQUFNd0QsaUJBQWlCUCxPQUFPQyxhQUFhTyxRQUFRLG1CQUFtQjtBQUN0RSxRQUFJRCxnQkFBZ0I7QUFDbEIsWUFBTXBCLFFBQU9nQixLQUFLTSxNQUFNRixjQUFjO0FBQ3RDbkIsY0FBUUQsS0FBSTtBQUNaakMsa0JBQVltRCxTQUFTbEIsTUFBS21CLEtBQUs7QUFBQSxJQUNqQztBQUFBLEVBQ0YsR0FBRSxFQUFFO0FBRUosUUFBTUksZUFBZUEsQ0FBQ2YsVUFBVTtBQUM5QkEsVUFBTUMsZUFBZTtBQUNyQkMsWUFBUUMsSUFBSSxnQkFBZ0JmLFVBQVVFLFFBQVE7QUFDOUNlLFdBQU9DLGFBQWFVLFdBQVcsbUJBQW1CO0FBQ2xEdkIsWUFBUSxJQUFJO0FBQ1psQyxnQkFBWW1ELFNBQVMsSUFBSTtBQUN6QmIsV0FBTyxjQUFjLFNBQVM7QUFDOUJELGFBQVMsR0FBRztBQUFBLEVBRWQ7QUFFQSxRQUFNcUIsbUJBQW1CLE9BQU9DLGVBQWU7QUFFN0MsUUFBRztBQUNILFlBQU1DLGVBQWUsTUFBTTVELFlBQVk2RCxPQUFPRixVQUFVO0FBQ3BEL0IsZUFBU0QsTUFBTW1DLE9BQU9GLFlBQVksQ0FBQztBQUNuQ3RCLGFBQU8sY0FBY3NCLGFBQWFHLEtBQUssT0FBT0gsYUFBYUksTUFBTSxVQUFVLFNBQVM7QUFDcEYzQixlQUFTLEdBQUc7QUFBQSxJQUNoQixTQUFRNEIsV0FBVTtBQUNkM0IsYUFBTyx5QkFBeUIsT0FBTztBQUN2Q0ssY0FBUXVCLE1BQU1ELFNBQVM7QUFDdkI1QixlQUFTLEdBQUc7QUFBQSxJQUNkO0FBQUEsRUFDSjtBQUVBLFFBQU04QixhQUFhLE9BQU9DLFVBQVM7QUFDakMsVUFBTUMsYUFBWTtBQUFBLE1BQ2hCcEMsTUFBTW1DLE1BQUtuQyxNQUFNcUMsTUFBTUYsTUFBS25DO0FBQUFBLE1BQzVCc0MsT0FBUUgsTUFBS0csUUFBTTtBQUFBLE1BQ25CUCxRQUFTSSxNQUFLSjtBQUFBQSxNQUNkRCxPQUFNSyxNQUFLTDtBQUFBQSxNQUNYUyxLQUFLSixNQUFLSTtBQUFBQSxJQUNaO0FBQ0EsUUFBRztBQUNELFlBQU1DLGNBQWMsTUFBTXpFLFlBQVkwRSxPQUFPTixNQUFLRSxJQUFJRCxVQUFVO0FBQ2hFekMsZUFBU0QsTUFBTWdELElBQUksQ0FBQUMsTUFBS0EsRUFBRU4sT0FBT0YsTUFBS0UsS0FBS0csY0FBYUcsQ0FBQyxDQUFDO0FBQUEsSUFDNUQsUUFBUTtBQUNOdEMsYUFBTywyQkFBMkIsT0FBTztBQUFBLElBQzNDO0FBQUEsRUFDRjtBQUVBLFFBQU11QyxlQUFlLE9BQU1ULFVBQVM7QUFDbEMsVUFBTVUsS0FBS2hDLE9BQU9pQyxRQUFRLGVBQWVYLE1BQUtMLEtBQUssT0FBT0ssTUFBS0osTUFBTSxHQUFHO0FBQ3hFLFFBQUdjLElBQUc7QUFDSixVQUFHO0FBQ0QsY0FBTTlFLFlBQVlnRixPQUFPWixNQUFLRSxFQUFFO0FBQ2hDMUMsaUJBQVNELE1BQU1zRCxPQUFPLENBQUFMLE1BQUtBLEVBQUVOLE9BQU9GLE1BQUtFLEVBQUUsQ0FBQztBQUFBLE1BRTlDLFFBQU87QUFDTGhDLGVBQU8sNkJBQTZCLE9BQU87QUFBQSxNQUM3QztBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUF6QyxZQUFVLE1BQU07QUFDZEcsZ0JBQVlrRixPQUFPLEVBQUVDO0FBQUFBLE1BQUssQ0FBQXhELFdBQ3hCQyxTQUFVRCxNQUFNO0FBQUEsSUFDbEI7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMLFFBQU15RCxRQUFRMUUsU0FBUyxZQUFZO0FBQ25DLFFBQU0wRCxPQUFPZ0IsUUFDVHpELE1BQU0wRCxLQUFLLENBQUFULE1BQUtBLEVBQUVOLE9BQU9jLE1BQU1FLE9BQU9oQixFQUFFLElBQ3hDO0FBRUosU0FDRSx1QkFBQyxhQUNELGlDQUFDLFNBQ0M7QUFBQSwyQkFBQyxTQUNDLGlDQUFDLFVBQU8sVUFBUyxVQUNmLGlDQUFDLFdBQ0M7QUFBQSw2QkFBQyxTQUFJLE9BQU8sRUFBRWlCLFVBQVUsR0FBR0MsVUFBVSxXQUFXQyxZQUFZLE9BQU8sR0FBRSx3QkFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVSO0FBQUEsTUFFUSx1QkFBQyxVQUFPLE9BQU0sV0FBVSxXQUFXaEYsTUFBTSxJQUFJLEtBQUkscUJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0Q7QUFBQSxNQUNyRHdCLFFBQVEsdUJBQUMsVUFBTyxPQUFNLFdBQVUsV0FBV3hCLE1BQU0sSUFBRyxXQUFVLHdCQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThEO0FBQUEsTUFDdEV3QixPQUFPLHVCQUFDLFVBQU8sT0FBTSxXQUFVLFNBQVN1QixjQUFjLHNCQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFELElBQzNELHVCQUFDLFVBQU8sT0FBTSxXQUFVLFdBQVcvQyxNQUFNLElBQUcsVUFBUyxxQkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwRDtBQUFBLFNBUjlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQSxLQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXQSxLQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQkE7QUFBQSxJQUNBLHVCQUFDLFNBQ0M7QUFBQSw2QkFBQyxnQkFBYSxnQkFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlDO0FBQUEsTUFFekMsdUJBQUMsVUFDQztBQUFBLCtCQUFDLFNBQU0sTUFBSyxLQUFJLFNBQVMsdUJBQUMsWUFBUyxTQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUIsS0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRDtBQUFBLFFBQ3BELHVCQUFDLFNBQU0sTUFBSyxVQUFTLFNBQVM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUM3QjtBQUFBLFlBQ0E7QUFBQSxZQUNBLHNCQUFzQixDQUFDLEVBQUVpRixPQUFPLE1BQU01RCxZQUFZNEQsT0FBT0MsS0FBSztBQUFBLFlBQzlELHNCQUFzQixDQUFDLEVBQUVELE9BQU8sTUFBTTFELFlBQVkwRCxPQUFPQyxLQUFLO0FBQUEsWUFDOUQsY0FBY25EO0FBQUFBO0FBQUFBLFVBTGM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0YsS0FMNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1HO0FBQUEsUUFDSCx1QkFBQyxTQUFNLE1BQUssV0FBVSxTQUFTLHVCQUFDLFlBQVMsWUFBWWtCLG9CQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVDLEtBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUU7QUFBQSxRQUd6RTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FDRTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDO0FBQUEsZ0JBQ0EsWUFBWSxNQUFNUyxXQUFXQyxJQUFJO0FBQUEsZ0JBQ2pDLGNBQWMsTUFBTVMsYUFBYVQsSUFBSTtBQUFBLGdCQUNyQyxhQUFhbkM7QUFBQUE7QUFBQUEsY0FKZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJb0I7QUFBQTtBQUFBLFVBUHhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVNHO0FBQUEsV0FyQkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVCQTtBQUFBLFNBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyQkE7QUFBQSxPQTdDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK0NBLEtBaERBO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpREE7QUFFSjtBQUFDUCxHQW5LS0QsS0FBRztBQUFBLFVBT1VkLGFBbUdIRCxRQUFRO0FBQUE7QUFBQSxNQTFHbEJlO0FBcUtOLGVBQWVBO0FBQUcsSUFBQUQsSUFBQW9FO0FBQUEsYUFBQXBFLElBQUE7QUFBQSxhQUFBb0UsS0FBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlUmVmIiwiQmxvZyIsImJsb2dTZXJ2aWNlIiwibG9naW5TZXJ2aWNlIiwiQmxvZ0Zvcm0iLCJUb2dnbGFibGUiLCJMb2dpbkZvcm0iLCJCcm93c2VyUm91dGVyIiwiUm91dGVyIiwiUm91dGVzIiwiUm91dGUiLCJMaW5rIiwidXNlTWF0Y2giLCJ1c2VOYXZpZ2F0ZSIsIkJsb2dMaXN0IiwiQ29udGFpbmVyIiwiVG9vbGJhciIsIkFsZXJ0IiwiQXBwQmFyIiwiQnV0dG9uIiwiTm90aWZpY2F0aW9uIiwibm90aWZpY2F0aW9uIiwidHlwZSIsIm1hcmdpblRvcCIsIm1hcmdpbkJvdHRvbSIsIm1lc3NhZ2UiLCJfYyIsIkFwcCIsIl9zIiwiYmxvZ3MiLCJzZXRCbG9ncyIsInVzZXJuYW1lIiwic2V0VXNlcm5hbWUiLCJwYXNzd29yZCIsInNldFBhc3N3b3JkIiwidXNlciIsInNldFVzZXIiLCJzZXROb3RpZmljYXRpb24iLCJibG9nRm9ybVJlZiIsIm5hdmlnYXRlIiwibm90aWZ5Iiwic2V0VGltZW91dCIsImhhbmRsZUxvZ2luIiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsImNvbnNvbGUiLCJsb2ciLCJsb2dpbiIsIndpbmRvdyIsImxvY2FsU3RvcmFnZSIsInNldEl0ZW0iLCJKU09OIiwic3RyaW5naWZ5Iiwic2V0VG9rZW4iLCJ0b2tlbiIsImxvZ2dlZFVzZXJKU09OIiwiZ2V0SXRlbSIsInBhcnNlIiwiaGFuZGxlTG9nb3V0IiwicmVtb3ZlSXRlbSIsImhhbmRsZUNyZWF0ZUJsb2ciLCJibG9nT2JqZWN0IiwicmV0dXJuZWRCbG9nIiwiY3JlYXRlIiwiY29uY2F0IiwidGl0bGUiLCJhdXRob3IiLCJleGNlcHRpb24iLCJlcnJvciIsImhhbmRsZUxpa2UiLCJibG9nIiwidXBkYXRlQmxvZyIsImlkIiwibGlrZXMiLCJ1cmwiLCJ1cGRhdGVkQmxvZyIsInVwZGF0ZSIsIm1hcCIsImIiLCJoYW5kbGVSZW1vdmUiLCJvayIsImNvbmZpcm0iLCJyZW1vdmUiLCJmaWx0ZXIiLCJnZXRBbGwiLCJ0aGVuIiwibWF0Y2giLCJmaW5kIiwicGFyYW1zIiwiZmxleEdyb3ciLCJmb250U2l6ZSIsImZvbnRXZWlnaHQiLCJ0YXJnZXQiLCJ2YWx1ZSIsIl9jMiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBcHAuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsdXNlUmVmIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgQmxvZyBmcm9tICcuL2NvbXBvbmVudHMvQmxvZydcbmltcG9ydCBibG9nU2VydmljZSBmcm9tICcuL3NlcnZpY2VzL2Jsb2dzJ1xuaW1wb3J0IGxvZ2luU2VydmljZSBmcm9tICcuL3NlcnZpY2VzL2xvZ2luJ1xuaW1wb3J0IEJsb2dGb3JtIGZyb20gJy4vY29tcG9uZW50cy9CbG9nRm9ybSdcbmltcG9ydCBUb2dnbGFibGUgZnJvbSAnLi9jb21wb25lbnRzL1RvZ2dsYWJsZScgLy8g4piF6L+95YqgXG5pbXBvcnQgTG9naW5Gb3JtIGZyb20gJy4vY29tcG9uZW50cy9Mb2dpbkZvcm0nIC8vIOKYhei/veWKoFxuaW1wb3J0IHtcbiAgQnJvd3NlclJvdXRlciBhcyBSb3V0ZXIsXG4gIFJvdXRlcywgUm91dGUsIExpbmssIHVzZU1hdGNoLHVzZU5hdmlnYXRlXG59IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgQmxvZ0xpc3QgZnJvbSAnLi9jb21wb25lbnRzL0Jsb2dMaXN0J1xuaW1wb3J0IHsgQ29udGFpbmVyLCBUb29sYmFyIH0gZnJvbSAnQG11aS9tYXRlcmlhbCdcbmltcG9ydCB7IEFsZXJ0LEFwcEJhcixCdXR0b24gfSBmcm9tICdAbXVpL21hdGVyaWFsJ1xuXG5cbiAgICAgICAgLy8gdXNlcm5hbWU6ICdtbHV1a2thaScsXG4gICAgICAgIC8vIHBhc3N3b3JkOiAnc2FsYWluZW4nXG5cbmNvbnN0IE5vdGlmaWNhdGlvbiA9ICh7IG5vdGlmaWNhdGlvbiB9KSA9PiB7XG4gIGlmICghbm90aWZpY2F0aW9uKSB7XG4gICAgcmV0dXJuIG51bGxcbiAgfVxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPXtub3RpZmljYXRpb24udHlwZSA9PT0gJ3N1Y2Nlc3MnID8gJ3N1Y2Nlc3MnIDogJ2Vycm9yJ30+XG4gICAgICA8QWxlcnQgc3R5bGU9e3ttYXJnaW5Ub3A6IDEwLCBtYXJnaW5Cb3R0b206IDEwfX0gc2V2ZXJpdHk9e25vdGlmaWNhdGlvbi50eXBlfT5cbiAgICAgIHtub3RpZmljYXRpb24ubWVzc2FnZX1cbiAgICAgIDwvQWxlcnQ+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuY29uc3QgQXBwID0gKCkgPT4ge1xuICBjb25zdCBbYmxvZ3MsIHNldEJsb2dzXSA9IHVzZVN0YXRlKFtdKVxuICBjb25zdCBbdXNlcm5hbWUsIHNldFVzZXJuYW1lXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbdXNlciwgc2V0VXNlcl0gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbbm90aWZpY2F0aW9uLCBzZXROb3RpZmljYXRpb25dID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgYmxvZ0Zvcm1SZWYgPSB1c2VSZWYoKSAvLyBUb2dnbGFibGXjga7plovplonnlKhcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpIC8vIOODreOCsOOCpOODs+WujOS6huW+jOOBrueUu+mdoumBt+enu+eUqFxuXG4gIGNvbnN0IG5vdGlmeSA9IChtZXNzYWdlLCB0eXBlID0gJ3N1Y2Nlc3MnKSA9PiB7XG4gICAgc2V0Tm90aWZpY2F0aW9uKHsgbWVzc2FnZSwgdHlwZSB9KVxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgc2V0Tm90aWZpY2F0aW9uKG51bGwpXG4gICAgfSwgNTAwMDApXG4gIH1cbiAgY29uc3QgaGFuZGxlTG9naW4gPSBhc3luYyAoZXZlbnQpID0+IHtcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXG4gICAgY29uc29sZS5sb2coJ2xvZ2dpbmcgaW4gd2l0aCcsIHVzZXJuYW1lLCBwYXNzd29yZClcblxuICAgIHRyeXtcbiAgICAgIGNvbnN0IHVzZXIgPSBhd2FpdCBsb2dpblNlcnZpY2UubG9naW4oeyB1c2VybmFtZSxwYXNzd29yZCB9KVxuICAgICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKFxuICAgICAgICAnbG9nZ2VkQmxvZ2FwcFVzZXInLCBKU09OLnN0cmluZ2lmeSh1c2VyKVxuICAgICAgKVxuICAgICAgbm90aWZ5KCdsb2dpbiBzdWNjZXNzJywgJ3N1Y2Nlc3MnKVxuICAgICAgYmxvZ1NlcnZpY2Uuc2V0VG9rZW4odXNlci50b2tlbilcbiAgICAgIHNldFVzZXIodXNlcilcbiAgICAgIHNldFVzZXJuYW1lKCcnKVxuICAgICAgc2V0UGFzc3dvcmQoJycpXG4gICAgICBuYXZpZ2F0ZSgnLycpIC8vIOODreOCsOOCpOODs+aIkOWKn+OBl+OBn+OCieODiOODg+ODl++8iOODluODreOCsOS4gOimp++8ieOBuOmBt+enu1xuICAgIH0gY2F0Y2gge1xuICAgICAgbm90aWZ5KCd3cm9uZyBjcmVkZW50aWFscycsICdlcnJvcicpXG4gICAgfVxuICB9XG5cblxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgbG9nZ2VkVXNlckpTT04gPSB3aW5kb3cubG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2xvZ2dlZEJsb2dhcHBVc2VyJylcbiAgICBpZiAobG9nZ2VkVXNlckpTT04pIHtcbiAgICAgIGNvbnN0IHVzZXIgPSBKU09OLnBhcnNlKGxvZ2dlZFVzZXJKU09OKVxuICAgICAgc2V0VXNlcih1c2VyKVxuICAgICAgYmxvZ1NlcnZpY2Uuc2V0VG9rZW4odXNlci50b2tlbilcbiAgICB9XG4gIH0sW10pXG5cbiAgY29uc3QgaGFuZGxlTG9nb3V0ID0gKGV2ZW50KSA9PiB7XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxuICAgIGNvbnNvbGUubG9nKCdsb2cgb3V0IHdpdGgnLCB1c2VybmFtZSwgcGFzc3dvcmQpXG4gICAgd2luZG93LmxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCdsb2dnZWRCbG9nYXBwVXNlcicpXG4gICAgc2V0VXNlcihudWxsKVxuICAgIGJsb2dTZXJ2aWNlLnNldFRva2VuKG51bGwpXG4gICAgbm90aWZ5KCdsb2dnZWQgb3V0JywgJ3N1Y2Nlc3MnKVxuICAgIG5hdmlnYXRlKCcvJykgLy8g44Ot44Kw44Kk44Oz5oiQ5Yqf44GX44Gf44KJ44OI44OD44OX77yI44OW44Ot44Kw5LiA6Kan77yJ44G46YG356e7XG5cbiAgfVxuXG4gIGNvbnN0IGhhbmRsZUNyZWF0ZUJsb2cgPSBhc3luYyAoYmxvZ09iamVjdCkgPT4ge1xuICAgIC8vIGJsb2dGb3JtUmVmLmN1cnJlbnQudG9nZ2xlVmlzaWJpbGl0eSgpXG4gICAgdHJ5e1xuICAgIGNvbnN0IHJldHVybmVkQmxvZyA9IGF3YWl0IGJsb2dTZXJ2aWNlLmNyZWF0ZShibG9nT2JqZWN0KVxuICAgICAgICBzZXRCbG9ncyhibG9ncy5jb25jYXQocmV0dXJuZWRCbG9nKSlcbiAgICAgICAgbm90aWZ5KGBhIG5ldyBibG9nICR7cmV0dXJuZWRCbG9nLnRpdGxlfSBieSAke3JldHVybmVkQmxvZy5hdXRob3J9IGFkZGVkYCwgJ3N1Y2Nlc3MnKVxuICAgICAgICBuYXZpZ2F0ZSgnLycpXG4gICAgfSBjYXRjaChleGNlcHRpb24pe1xuICAgICAgICBub3RpZnkoJ2ZhaWxlZCB0byBjcmVhdGUgYmxvZycsICdlcnJvcicpXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoZXhjZXB0aW9uKVxuICAgICAgICBuYXZpZ2F0ZSgnLycpXG4gICAgICB9XG4gIH1cblxuICBjb25zdCBoYW5kbGVMaWtlID0gYXN5bmMgKGJsb2cpID0+IHtcbiAgICBjb25zdCB1cGRhdGVCbG9nID17XG4gICAgICB1c2VyIDpibG9nLnVzZXI/LmlkIHx8IGJsb2cudXNlcixcbiAgICAgIGxpa2VzIDogYmxvZy5saWtlcysxLFxuICAgICAgYXV0aG9yIDogYmxvZy5hdXRob3IsXG4gICAgICB0aXRsZTpibG9nLnRpdGxlLFxuICAgICAgdXJsOiBibG9nLnVybFxuICAgIH1cbiAgICB0cnl7XG4gICAgICBjb25zdCB1cGRhdGVkQmxvZyA9IGF3YWl0IGJsb2dTZXJ2aWNlLnVwZGF0ZShibG9nLmlkLCB1cGRhdGVCbG9nKVxuICAgICAgc2V0QmxvZ3MoYmxvZ3MubWFwKGIgPT4gYi5pZCA9PT0gYmxvZy5pZCA/IHVwZGF0ZWRCbG9nIDpiKSlcbiAgICB9IGNhdGNoIHtcbiAgICAgIG5vdGlmeSgnZmFpbGVkIHRvIGxpa2UgdGhlIGJsb2cnLCAnZXJyb3InKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGhhbmRsZVJlbW92ZSA9IGFzeW5jKGJsb2cpID0+IHtcbiAgICBjb25zdCBvayA9IHdpbmRvdy5jb25maXJtKGBSZW1vdmUgYmxvZyAke2Jsb2cudGl0bGV9IGJ5ICR7YmxvZy5hdXRob3J9P2ApXG4gICAgaWYob2spe1xuICAgICAgdHJ5e1xuICAgICAgICBhd2FpdCBibG9nU2VydmljZS5yZW1vdmUoYmxvZy5pZClcbiAgICAgICAgc2V0QmxvZ3MoYmxvZ3MuZmlsdGVyKGIgPT4gYi5pZCAhPT0gYmxvZy5pZCkpXG5cbiAgICAgIH0gY2F0Y2h7XG4gICAgICAgIG5vdGlmeSgnZmFpbGVkIHRvIHJlbW92ZSB0aGUgYmxvZycsICdlcnJvcicpXG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBibG9nU2VydmljZS5nZXRBbGwoKS50aGVuKGJsb2dzID0+XG4gICAgICBzZXRCbG9ncyggYmxvZ3MgKVxuICAgIClcbiAgfSwgW10pXG5cbiAgY29uc3QgbWF0Y2ggPSB1c2VNYXRjaCgnL2Jsb2dzLzppZCcpXG4gIGNvbnN0IGJsb2cgPSBtYXRjaFxuICAgID8gYmxvZ3MuZmluZChiID0+IGIuaWQgPT09IG1hdGNoLnBhcmFtcy5pZClcbiAgICA6IG51bGxcblxuICByZXR1cm4gKFxuICAgIDxDb250YWluZXI+XG4gICAgPGRpdj5cbiAgICAgIDxkaXY+XG4gICAgICAgIDxBcHBCYXIgcG9zaXRpb249XCJzdGF0aWNcIj5cbiAgICAgICAgICA8VG9vbGJhcj5cbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleEdyb3c6IDEsIGZvbnRTaXplOiAnMS4yNXJlbScsIGZvbnRXZWlnaHQ6ICdib2xkJyB9fT5cbiAgICAgIEJsb2cgQXBwXG4gICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxCdXR0b24gY29sb3I9XCJpbmhlcml0XCIgY29tcG9uZW50PXtMaW5rfSB0byA9XCIvXCI+YmxvZ3M8L0J1dHRvbj5cbiAgICAgICAgICAgIHt1c2VyICYmIDxCdXR0b24gY29sb3I9XCJpbmhlcml0XCIgY29tcG9uZW50PXtMaW5rfSB0bz1cIi9jcmVhdGVcIj5uZXcgYmxvZzwvQnV0dG9uPn1cbiAgICAgICAgICAgIHt1c2VyPyAoPEJ1dHRvbiBjb2xvcj1cImluaGVyaXRcIiBvbkNsaWNrPXtoYW5kbGVMb2dvdXR9PmxvZ291dDwvQnV0dG9uPik6XG4gICAgICAgICAgICAgKDxCdXR0b24gY29sb3I9XCJpbmhlcml0XCIgY29tcG9uZW50PXtMaW5rfSB0bz1cIi9sb2dpblwiPmxvZ2luPC9CdXR0b24+KX1cbiAgICAgICAgICA8L1Rvb2xiYXI+XG4gICAgICAgIDwvQXBwQmFyPlxuICAgICAgICB7LyogPExpbmsgdG89XCIvXCI+YmxvZ3M8L0xpbms+eycgJ31cbiAgICAgICAge3VzZXIgJiYgKDxMaW5rIHRvPVwiL2NyZWF0ZVwiPm5ldyBibG9nPC9MaW5rPil9eycgJ31cbiAgICAgICAge3VzZXI/ICAoPGJ1dHRvbiBvbkNsaWNrPXtoYW5kbGVMb2dvdXR9PmxvZ291dDwvYnV0dG9uPik6ICg8TGluayB0bz1cIi9sb2dpblwiPmxvZ2luPC9MaW5rPil9ICovfVxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2PlxuICAgICAgICA8Tm90aWZpY2F0aW9uIG5vdGlmaWNhdGlvbj17bm90aWZpY2F0aW9ufS8+XG5cbiAgICAgICAgPFJvdXRlcz5cbiAgICAgICAgICA8Um91dGUgcGF0aD1cIi9cIiBlbGVtZW50PXs8QmxvZ0xpc3QgYmxvZ3M9e2Jsb2dzfSAvPn0gLz5cbiAgICAgICAgICA8Um91dGUgcGF0aD1cIi9sb2dpblwiIGVsZW1lbnQ9ezxMb2dpbkZvcm1cbiAgICAgICAgICAgIHVzZXJuYW1lPXt1c2VybmFtZX1cbiAgICAgICAgICAgIHBhc3N3b3JkPXtwYXNzd29yZH1cbiAgICAgICAgICAgIGhhbmRsZVVzZXJuYW1lQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0VXNlcm5hbWUodGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgIGhhbmRsZVBhc3N3b3JkQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0UGFzc3dvcmQodGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgIGhhbmRsZVN1Ym1pdD17aGFuZGxlTG9naW59XG4gICAgICAgICAgLz59Lz5cbiAgICAgICAgICA8Um91dGUgcGF0aD1cIi9jcmVhdGVcIiBlbGVtZW50PXs8QmxvZ0Zvcm0gY3JlYXRlQmxvZz17aGFuZGxlQ3JlYXRlQmxvZ30vPn0vPlxuXG5cbiAgICAgICAgICA8Um91dGVcbiAgICAgICAgICAgIHBhdGg9XCIvYmxvZ3MvOmlkXCJcbiAgICAgICAgICAgIGVsZW1lbnQ9e1xuICAgICAgICAgICAgICA8QmxvZ1xuICAgICAgICAgICAgICAgIGJsb2c9e2Jsb2d9XG4gICAgICAgICAgICAgICAgaGFuZGxlTGlrZT17KCkgPT4gaGFuZGxlTGlrZShibG9nKX1cbiAgICAgICAgICAgICAgICBoYW5kbGVSZW1vdmU9eygpID0+IGhhbmRsZVJlbW92ZShibG9nKX1cbiAgICAgICAgICAgICAgICBjdXJyZW50VXNlcj17dXNlcn1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAvPlxuICAgICAgICA8L1JvdXRlcz5cbiAgICAgIDwvZGl2PlxuXG4gICAgPC9kaXY+XG4gICAgPC9Db250YWluZXI+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwIl0sImZpbGUiOiIvVXNlcnMvdGFrYWhhc2hpc2h1dXRhL0Rlc2t0b3AvU2NyaXB0L0Z1bGxTdGFjay9wYXJ0NWZvcnN1Ym1pc3Npb24vYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL0FwcC5qc3gifQ==