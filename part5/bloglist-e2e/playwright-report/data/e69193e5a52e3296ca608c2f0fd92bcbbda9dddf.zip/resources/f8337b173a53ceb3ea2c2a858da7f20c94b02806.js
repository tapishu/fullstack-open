import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BlogForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f4884521"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/BlogForm.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=f4884521"; const useState = __vite__cjsImport3_react["useState"];
import { TextField, Button } from "/node_modules/.vite/deps/@mui_material.js?v=93970f84";
const BlogForm = ({ createBlog }) => {
  _s();
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [url, setUrl] = useState("");
  const handleSubmit = (event) => {
    event.preventDefault();
    createBlog({
      title,
      author,
      url
    });
    setTitle("");
    setAuthor("");
    setUrl("");
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "create new" }, void 0, false, {
      fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 47,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(
        TextField,
        {
          label: "title:",
          value: title,
          onChange: ({ target }) => setTitle(target.value)
        },
        void 0,
        false,
        {
          fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/BlogForm.jsx",
          lineNumber: 50,
          columnNumber: 9
        },
        this
      ) }, void 0, false, {
        fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/BlogForm.jsx",
        lineNumber: 49,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(
        TextField,
        {
          label: "author:",
          value: author,
          onChange: ({ target }) => setAuthor(target.value)
        },
        void 0,
        false,
        {
          fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/BlogForm.jsx",
          lineNumber: 56,
          columnNumber: 9
        },
        this
      ) }, void 0, false, {
        fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/BlogForm.jsx",
        lineNumber: 55,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(
        TextField,
        {
          label: "url:",
          value: url,
          onChange: ({ target }) => setUrl(target.value)
        },
        void 0,
        false,
        {
          fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/BlogForm.jsx",
          lineNumber: 62,
          columnNumber: 9
        },
        this
      ) }, void 0, false, {
        fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/BlogForm.jsx",
        lineNumber: 61,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { type: "submit", variant: "contained", style: { marginTop: 10 }, color: "primary", children: "create" }, void 0, false, {
        fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/BlogForm.jsx",
        lineNumber: 67,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 48,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/BlogForm.jsx",
    lineNumber: 46,
    columnNumber: 5
  }, this);
};
_s(BlogForm, "g+g+3j1LiFjJCP23+NliFDHOHt4=");
_c = BlogForm;
export default BlogForm;
var _c;
$RefreshReg$(_c, "BlogForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/BlogForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/BlogForm.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQTNCTixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsV0FBV0MsY0FBYztBQUVsQyxNQUFNQyxXQUFVQSxDQUFDLEVBQUVDLFdBQVcsTUFBTTtBQUFBQyxLQUFBO0FBQ2xDLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJUCxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDUSxRQUFRQyxTQUFTLElBQUlULFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUNVLEtBQUtDLE1BQU0sSUFBSVgsU0FBUyxFQUFFO0FBR2pDLFFBQU1ZLGVBQWVBLENBQUNDLFVBQVU7QUFDOUJBLFVBQU1DLGVBQWU7QUFFckJWLGVBQVc7QUFBQSxNQUNURTtBQUFBQSxNQUNBRTtBQUFBQSxNQUNBRTtBQUFBQSxJQUNGLENBQUM7QUFFREgsYUFBUyxFQUFFO0FBQ1hFLGNBQVUsRUFBRTtBQUNaRSxXQUFPLEVBQUU7QUFBQSxFQUNYO0FBSUEsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsUUFBRywwQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWM7QUFBQSxJQUNkLHVCQUFDLFVBQUssVUFBVUMsY0FDZDtBQUFBLDZCQUFDLFNBQ0Q7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNELE9BQU07QUFBQSxVQUNBLE9BQU9OO0FBQUFBLFVBQ1AsVUFBVSxDQUFDLEVBQUVTLE9BQU8sTUFBTVIsU0FBU1EsT0FBT0MsS0FBSztBQUFBO0FBQUEsUUFIckQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BR3VELEtBSnZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0UsdUJBQUMsU0FDSDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0QsT0FBTTtBQUFBLFVBQ0EsT0FBT1I7QUFBQUEsVUFDUCxVQUFVLENBQUMsRUFBRU8sT0FBTyxNQUFNTixVQUFVTSxPQUFPQyxLQUFLO0FBQUE7QUFBQSxRQUh0RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFHd0QsS0FKdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtGO0FBQUEsTUFDRSx1QkFBQyxTQUNIO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRCxPQUFNO0FBQUEsVUFDQSxPQUFPTjtBQUFBQSxVQUNQLFVBQVUsQ0FBQyxFQUFFSyxPQUFPLE1BQU1KLE9BQU9JLE9BQU9DLEtBQUs7QUFBQTtBQUFBLFFBSG5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUdxRCxLQUpuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0Y7QUFBQSxNQUNBLHVCQUFDLFVBQU8sTUFBSyxVQUFTLFNBQVMsYUFBWSxPQUFPLEVBQUVDLFdBQVcsR0FBRyxHQUFHLE9BQU0sV0FBVSxzQkFBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRjtBQUFBLFNBbkI3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUJBO0FBQUEsT0F2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdCQTtBQUVKO0FBQUNaLEdBakRLRixVQUFRO0FBQUEsS0FBUkE7QUFrRE4sZUFBZUE7QUFBUSxJQUFBZTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIlRleHRGaWVsZCIsIkJ1dHRvbiIsIkJsb2dGb3JtIiwiY3JlYXRlQmxvZyIsIl9zIiwidGl0bGUiLCJzZXRUaXRsZSIsImF1dGhvciIsInNldEF1dGhvciIsInVybCIsInNldFVybCIsImhhbmRsZVN1Ym1pdCIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJ0YXJnZXQiLCJ2YWx1ZSIsIm1hcmdpblRvcCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkJsb2dGb3JtLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgVGV4dEZpZWxkLCBCdXR0b24gfSBmcm9tICdAbXVpL21hdGVyaWFsJ1xuXG5jb25zdCBCbG9nRm9ybSA9KHsgY3JlYXRlQmxvZyB9KSA9PiB7XG4gIGNvbnN0IFt0aXRsZSwgc2V0VGl0bGVdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFthdXRob3IsIHNldEF1dGhvcl0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3VybCwgc2V0VXJsXSA9IHVzZVN0YXRlKCcnKVxuXG5cbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gKGV2ZW50KSA9PiB7XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxuICAgIC8vIOimqu+8iEFwcO+8ieOBi+OCiea4oeOBleOCjOOBnyBjcmVhdGVCbG9nIOmWouaVsOOBq+WFpeWKm+WGheWuueOCkua4oeOBmVxuICAgIGNyZWF0ZUJsb2coe1xuICAgICAgdGl0bGU6IHRpdGxlLFxuICAgICAgYXV0aG9yOiBhdXRob3IsXG4gICAgICB1cmw6IHVybFxuICAgIH0pXG5cbiAgICBzZXRUaXRsZSgnJylcbiAgICBzZXRBdXRob3IoJycpXG4gICAgc2V0VXJsKCcnKVxuICB9XG5cblxuICAgICAgICBcbiAgcmV0dXJuKFxuICAgIDxkaXY+XG4gICAgICA8aDI+Y3JlYXRlIG5ldzwvaDI+XG4gICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fT5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgPFRleHRGaWVsZFxuICAgICAgICBsYWJlbD1cInRpdGxlOlwiXG4gICAgICAgICAgICAgIHZhbHVlPXt0aXRsZX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRUaXRsZSh0YXJnZXQudmFsdWUpfS8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgIDxUZXh0RmllbGRcbiAgICAgICAgbGFiZWw9XCJhdXRob3I6XCJcbiAgICAgICAgICAgICAgdmFsdWU9e2F1dGhvcn1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRBdXRob3IodGFyZ2V0LnZhbHVlKX0vPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICA8VGV4dEZpZWxkXG4gICAgICAgIGxhYmVsPVwidXJsOlwiXG4gICAgICAgICAgICAgIHZhbHVlPXt1cmx9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0VXJsKHRhcmdldC52YWx1ZSl9Lz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxCdXR0b24gdHlwZT1cInN1Ym1pdFwiIHZhcmlhbnQgPVwiY29udGFpbmVkXCIgc3R5bGU9e3sgbWFyZ2luVG9wOiAxMCB9fSBjb2xvcj0ncHJpbWFyeSc+Y3JlYXRlPC9CdXR0b24+XG5cbiAgICAgIDwvZm9ybT5cbiAgICA8L2Rpdj5cbiAgKVxufVxuZXhwb3J0IGRlZmF1bHQgQmxvZ0Zvcm0iXSwiZmlsZSI6Ii9Vc2Vycy90YWthaGFzaGlzaHV1dGEvRGVza3RvcC9TY3JpcHQvRnVsbFN0YWNrL3BhcnQ1Zm9yc3VibWlzc2lvbi9ibG9nbGlzdC1mcm9udGVuZC9zcmMvY29tcG9uZW50cy9CbG9nRm9ybS5qc3gifQ==