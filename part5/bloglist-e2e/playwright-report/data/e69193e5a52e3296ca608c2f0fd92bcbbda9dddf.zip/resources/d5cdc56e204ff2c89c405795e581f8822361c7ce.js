import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/LoginForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f4884521"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/LoginForm.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { TextField, Button } from "/node_modules/.vite/deps/@mui_material.js?v=93970f84";
const LoginForm = (props) => {
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Login" }, void 0, false, {
      fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/LoginForm.jsx",
      lineNumber: 27,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: props.handleSubmit, children: [
      /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(
        TextField,
        {
          label: "username",
          value: props.username,
          onChange: props.handleUsernameChange
        },
        void 0,
        false,
        {
          fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/LoginForm.jsx",
          lineNumber: 30,
          columnNumber: 9
        },
        this
      ) }, void 0, false, {
        fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/LoginForm.jsx",
        lineNumber: 29,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(
        TextField,
        {
          label: "password",
          value: props.password,
          onChange: props.handlePasswordChange
        },
        void 0,
        false,
        {
          fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/LoginForm.jsx",
          lineNumber: 36,
          columnNumber: 9
        },
        this
      ) }, void 0, false, {
        fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/LoginForm.jsx",
        lineNumber: 35,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(Button, { type: "submit", variant: "contained", style: { marginTop: 10 }, color: "primary", children: "login" }, void 0, false, {
        fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/LoginForm.jsx",
        lineNumber: 62,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/LoginForm.jsx",
        lineNumber: 61,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/LoginForm.jsx",
      lineNumber: 28,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/LoginForm.jsx",
    lineNumber: 26,
    columnNumber: 5
  }, this);
};
_c = LoginForm;
export default LoginForm;
var _c;
$RefreshReg$(_c, "LoginForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/LoginForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/components/LoginForm.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT007Ozs7Ozs7Ozs7Ozs7Ozs7QUFQTixTQUFTQSxXQUFXQyxjQUFjO0FBSWxDLE1BQU1DLFlBQVlBLENBQUNDLFVBQVU7QUFDM0IsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsUUFBRyxxQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVM7QUFBQSxJQUNULHVCQUFDLFVBQUssVUFBVUEsTUFBTUMsY0FDcEI7QUFBQSw2QkFBQyxTQUNEO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRCxPQUFNO0FBQUEsVUFDTixPQUFPRCxNQUFNRTtBQUFBQSxVQUNiLFVBQVVGLE1BQU1HO0FBQUFBO0FBQUFBLFFBSGhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUdxQyxLQUpyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLFNBQ0Q7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNELE9BQU87QUFBQSxVQUNQLE9BQU9ILE1BQU1JO0FBQUFBLFVBQ2IsVUFBVUosTUFBTUs7QUFBQUE7QUFBQUEsUUFIaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BR3FDLEtBSnJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BcUJFLHVCQUFDLFNBQ0QsaUNBQUMsVUFBTyxNQUFLLFVBQVMsU0FBUyxhQUFZLE9BQU8sRUFBRUMsV0FBVyxHQUFHLEdBQUcsT0FBTSxXQUFVLHFCQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBGLEtBRDFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFRjtBQUFBLFNBbkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQ0E7QUFBQSxPQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUNBO0FBRUo7QUFBQ0MsS0EzQ0tSO0FBNkNOLGVBQWVBO0FBQVMsSUFBQVE7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiVGV4dEZpZWxkIiwiQnV0dG9uIiwiTG9naW5Gb3JtIiwicHJvcHMiLCJoYW5kbGVTdWJtaXQiLCJ1c2VybmFtZSIsImhhbmRsZVVzZXJuYW1lQ2hhbmdlIiwicGFzc3dvcmQiLCJoYW5kbGVQYXNzd29yZENoYW5nZSIsIm1hcmdpblRvcCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkxvZ2luRm9ybS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgVGV4dEZpZWxkLCBCdXR0b24gfSBmcm9tICdAbXVpL21hdGVyaWFsJ1xuXG5cbi8vIHNyYy9jb21wb25lbnRzL0xvZ2luRm9ybS5qc3hcbmNvbnN0IExvZ2luRm9ybSA9IChwcm9wcykgPT4ge1xuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8aDI+TG9naW48L2gyPlxuICAgICAgPGZvcm0gb25TdWJtaXQ9e3Byb3BzLmhhbmRsZVN1Ym1pdH0+XG4gICAgICAgIDxkaXY+XG4gICAgICAgIDxUZXh0RmllbGRcbiAgICAgICAgbGFiZWw9XCJ1c2VybmFtZVwiXG4gICAgICAgIHZhbHVlPXtwcm9wcy51c2VybmFtZX1cbiAgICAgICAgb25DaGFuZ2U9e3Byb3BzLmhhbmRsZVVzZXJuYW1lQ2hhbmdlfS8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2PlxuICAgICAgICA8VGV4dEZpZWxkXG4gICAgICAgIGxhYmVsID1cInBhc3N3b3JkXCJcbiAgICAgICAgdmFsdWU9e3Byb3BzLnBhc3N3b3JkfVxuICAgICAgICBvbkNoYW5nZT17cHJvcHMuaGFuZGxlUGFzc3dvcmRDaGFuZ2V9Lz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIHsvKiA8ZGl2PlxuICAgICAgICAgIDxsYWJlbD5cbiAgICAgICAgICAgIHVzZXJuYW1lXG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICB2YWx1ZT17cHJvcHMudXNlcm5hbWV9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXtwcm9wcy5oYW5kbGVVc2VybmFtZUNoYW5nZX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgPC9kaXY+ICovfVxuICAgICAgICB7LyogPGRpdj5cbiAgICAgICAgICA8bGFiZWw+XG4gICAgICAgICAgICBwYXNzd29yZFxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgIHZhbHVlPXtwcm9wcy5wYXNzd29yZH1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9e3Byb3BzLmhhbmRsZVBhc3N3b3JkQ2hhbmdlfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICA8L2Rpdj4gKi99XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJzdWJtaXRcIiB2YXJpYW50ID1cImNvbnRhaW5lZFwiIHN0eWxlPXt7IG1hcmdpblRvcDogMTAgfX0gY29sb3I9J3ByaW1hcnknPmxvZ2luPC9CdXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9mb3JtPlxuICAgIDwvZGl2PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IExvZ2luRm9ybVxuIl0sImZpbGUiOiIvVXNlcnMvdGFrYWhhc2hpc2h1dXRhL0Rlc2t0b3AvU2NyaXB0L0Z1bGxTdGFjay9wYXJ0NWZvcnN1Ym1pc3Npb24vYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvTG9naW5Gb3JtLmpzeCJ9