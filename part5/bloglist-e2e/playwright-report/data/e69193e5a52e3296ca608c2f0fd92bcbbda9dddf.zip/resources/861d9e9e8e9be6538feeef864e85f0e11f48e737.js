import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f4884521"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=650a6391"; const ReactDOM = __vite__cjsImport1_reactDom_client.__esModule ? __vite__cjsImport1_reactDom_client.default : __vite__cjsImport1_reactDom_client;
import { BrowserRouter as Router } from "/node_modules/.vite/deps/react-router-dom.js?v=099a5fac";
import App from "/src/App.jsx?t=1791067269811";
ReactDOM.createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxDEV(Router, { children: /* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
    fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/main.jsx",
    lineNumber: 7,
    columnNumber: 5
  }, this) }, void 0, false, {
    fileName: "/Users/takahashishuuta/Desktop/Script/FullStack/part5forsubmission/bloglist-frontend/src/main.jsx",
    lineNumber: 6,
    columnNumber: 3
  }, this)
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBTUk7QUFOSixPQUFPQSxjQUFjO0FBQ3JCLFNBQVNDLGlCQUFpQkMsY0FBYztBQUN4QyxPQUFPQyxTQUFTO0FBRWhCSCxTQUFTSSxXQUFXQyxTQUFTQyxlQUFlLE1BQU0sQ0FBQyxFQUFFQztBQUFBQSxFQUNuRCx1QkFBQyxVQUNDLGlDQUFDLFNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFJLEtBRE47QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBQ0YiLCJuYW1lcyI6WyJSZWFjdERPTSIsIkJyb3dzZXJSb3V0ZXIiLCJSb3V0ZXIiLCJBcHAiLCJjcmVhdGVSb290IiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInJlbmRlciJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJtYWluLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3RET00gZnJvbSAncmVhY3QtZG9tL2NsaWVudCdcbmltcG9ydCB7IEJyb3dzZXJSb3V0ZXIgYXMgUm91dGVyIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcbmltcG9ydCBBcHAgZnJvbSAnLi9BcHAnXG5cblJlYWN0RE9NLmNyZWF0ZVJvb3QoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Jvb3QnKSkucmVuZGVyKFxuICA8Um91dGVyPlxuICAgIDxBcHAgLz5cbiAgPC9Sb3V0ZXI+XG4pXG4iXSwiZmlsZSI6Ii9Vc2Vycy90YWthaGFzaGlzaHV1dGEvRGVza3RvcC9TY3JpcHQvRnVsbFN0YWNrL3BhcnQ1Zm9yc3VibWlzc2lvbi9ibG9nbGlzdC1mcm9udGVuZC9zcmMvbWFpbi5qc3gifQ==